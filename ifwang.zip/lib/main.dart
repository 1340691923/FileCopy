/*

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:ifwang/utils/test1.dart';
import 'package:ifwang/utils/test2.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key, this.title}) : super(key: key);

  final String? title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<SubtitleEntry> _subtitleList = [];

  @override
  void initState() {
    loadData();
    super.initState();
  }

  loadData() async {
    var jsonStr =
    await DefaultAssetBundle.of(context).loadString('assets/subtitle.txt');
    var list = jsonStr.split(RegExp('\n'));
    list.forEach((f) {
      if (f.isNotEmpty) {
        var r = f.split(RegExp(' '));
        if (r.length >= 2) {
          _subtitleList.add(SubtitleEntry(r[0], r[1]));
        }
      }
    });
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('弹幕'),
      ),
      body: Stack(
        children: <Widget>[

          Positioned.fill(
              child: Subtitle(
                _subtitleList,
                diameterRatio: 2,
                selectedTextStyle: TextStyle(color: Colors.red, fontSize: 18),
                unSelectedTextStyle: TextStyle(
                  color: Colors.black.withOpacity(.6),
                ),
                itemExtent: 45,
              ))
        ],
      ),
    );
  }
}
*/



import 'package:fijkplayer/fijkplayer.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:ifwang/pages/bofang.dart';
import 'package:ifwang/utils/ShowConfigAbs.dart';
import 'package:ifwang/utils/fijkplayer_skin.dart';
import 'package:ifwang/utils/httputil.dart';
import 'package:ifwang/utils/icons.dart';
import 'package:ifwang/utils/schema.dart' show VideoSourceFormat;
import 'package:ifwang/utils/srt.dart';
import 'dart:convert' show json;

import 'package:ifwang/utils/toast.dart';
import 'package:webview_flutter/webview_flutter.dart';

Future<void> main() async {

  //debugPaintSizeEnabled = true;
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
      .then((_) {
    runApp(new MyApp());
  });
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: Scaffold(
        body:
        /*GestureDetector(child:  ListWheelScrollView.useDelegate(
          perspective: 0.001,
          onSelectedItemChanged: (index){
            print("onSelectedItemChanged $index");
          },
          diameterRatio: 2.0,
          itemExtent: 45,
          childDelegate:
          ListWheelChildBuilderDelegate(
              builder: (context, index) {
                return Text("data $index");
              },
              childCount: 10),
        ),onTap: ()=>{print("tap")},)*/

        ListView(
          children: <Widget>[
            // 测试
            // VideoDetailPage(videoList),
            HomeIndex()
          ],
        ),
      ),
    );
  }
}

class HomeIndex extends StatefulWidget {
  @override
  HomeIndexState createState() => HomeIndexState();
}

Map<String, List<Map<String, dynamic>>> videoList = {
  "video": [
    {
      "name": "天空资源2",
      "list": [
        {
          //"url": "https://test.lynlzqy.com/bsqb/view/sdk/test/test2.m3u8",//
          "url": "https://test.lynlzqy.com/bsqb/view/sdk/test2.mp4",//
          "name": "综艺2",
          "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/test2en.srt",
          "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/test2cn.srt",
        },
        {
          "url": "https://test.lynlzqy.com/bsqb/view/sdk/test00.mp4",//
          //"url": "https://test.lynlzqy.com/bsqb/view/sdk/xiao/ene.m3u8",//
          "name": "综艺",
          "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/test_en.srt",
          "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/test_cn.srt",
        },

        {
          "url": "https://static.smartisanos.cn/common/video/video-jgpro.mp4",
          "name": "锤子2",
          "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/test_en.srt",
          "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/test_cn.srt",
        }
      ]
    },
    {
      "name": "天空资源",
      "list": [
        {
          "url": "https://n1.szjal.cn/20210428/lsNZ6QAL/index.m3u8",
          "name": "综艺",
          "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/1.mp4",
          "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/2.mp4",
        },
     /*   {
          "url": "https://static.smartisanos.cn/common/video/t1-ui.mp4",
          "name": "锤子1",
          "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/3.mp4",
          "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/4.mp4",
        },
        {
          "url": "https://static.smartisanos.cn/common/video/video-jgpro.mp4",
          "name": "锤子2",
          "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/5.mp4",
          "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/6.mp4",
        }*/
      ]
    },
  ]
};

class HomeIndexState extends State<HomeIndex> {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ButtonStyle(
        shape: MaterialStateProperty.all(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        elevation: MaterialStateProperty.all(0),
        backgroundColor: MaterialStateProperty.all(Colors.lightBlueAccent),
      ),
      onPressed: () async {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => Bofang(videoList)));
      },
      child: Text(
        "按钮",
        style: TextStyle(
          color: Colors.white,
        ),
      ),
    );
  }
}
