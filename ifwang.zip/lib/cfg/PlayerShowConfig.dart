// 定制UI配置项



import 'package:ifwang/utils/ShowConfigAbs.dart';

class PlayerShowConfig implements ShowConfigAbs {
  bool drawerBtn = true;
  bool nextBtn = true;
  bool speedBtn = true;
  bool topBar = true;
  bool lockBtn = true;
  bool autoNext = true;
  bool bottomPro = true;
  bool stateAuto = true;
}