
import 'package:flutter/cupertino.dart';
import 'package:ifwang/utils/httputil.dart';

class Word{

  static getWordParse(BuildContext context,String kw) async {

    var httputil = new HttpUtil();

    var response = await httputil.get(context,"/GetWordParse",data: {"word":kw});

    return response;
  }
}

