import 'dart:async';

import 'package:fijkplayer/fijkplayer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ifwang/cfg/PlayerShowConfig.dart';
import 'package:ifwang/utils/Const.dart';
import 'package:ifwang/utils/ShowConfigAbs.dart';
import 'package:ifwang/utils/fijkplayer_skin.dart';
import 'package:ifwang/utils/httputil.dart';
import 'package:ifwang/utils/schema.dart';
import 'package:ifwang/utils/srt.dart';
import 'package:wakelock/wakelock.dart';

class VideoDetailPage extends StatefulWidget {
  final BuildContext? currentCtx;

  bool playMovie = true;

  VideoDetailPage(this.currentCtx, this.videoList, this.playMovie);

  Map<String, List<Map<String, dynamic>>> videoList = {
    "video": [
      {
        "name": "天空资源",
        "list": [
          {
            "url": "https://test.lynlzqy.com/bsqb/view/sdk/test.mp4",
            "name": "综艺",
            "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/test_en.srt",
            "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/test_cn.srt",
          },
          {
            "url": "https://static.smartisanos.cn/common/video/t1-ui.mp4",
            "name": "锤子1",
            "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/test_en.srt",
            "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/test_cn.srt",
          },
          {
            "url": "https://static.smartisanos.cn/common/video/video-jgpro.mp4",
            "name": "锤子2",
            "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/test_en.srt",
            "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/test_cn.srt",
          }
        ]
      },
      {
        "name": "天空资源",
        "list": [
          {
            "url": "https://n1.szjal.cn/20210428/lsNZ6QAL/index.m3u8",
            "name": "综艺",
            "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/1.mp4",
            "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/2.mp4",
          },
          {
            "url": "https://static.smartisanos.cn/common/video/t1-ui.mp4",
            "name": "锤子1",
            "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/3.mp4",
            "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/4.mp4",
          },
          {
            "url": "https://static.smartisanos.cn/common/video/video-jgpro.mp4",
            "name": "锤子2",
            "encrt": "https://test.lynlzqy.com/bsqb/view/sdk/5.mp4",
            "cncrt": "https://test.lynlzqy.com/bsqb/view/sdk/6.mp4",
          }
        ]
      },
    ]
  };

  @override
  _VideoDetailPageState createState() {
    print("widget.playMovie ${playMovie}");
    return _VideoDetailPageState();
  }
}

class _VideoDetailPageState extends State<VideoDetailPage>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  final FijkPlayer player = FijkPlayer();

  VideoSourceFormat? _videoSourceTabs;
  late TabController _tabController;
  late TabController _enKwtabController;

  int _curTabIdx = 0;
  int _curActiveIdx = 0;
  int clickKw = -1;
  int currentPlayIndex = 0;

  // ignore: non_constant_identifier_names
  ShowConfigAbs v_cfg = PlayerShowConfig();

  @override
  void dispose() {
    print("close");
    WidgetsBinding.instance!.removeObserver(this);
    closeSeviceTimer();
    player.dispose();
    _tabController.dispose();
    _enKwtabController.dispose();
    super.dispose();
  }

  @override
  Future<Null> didChangeAppLifecycleState(AppLifecycleState state) async {
    switch (state) {
      case AppLifecycleState.resumed: //后台切前台
        print("resumed");
        break;
      case AppLifecycleState.inactive:
        print("inactive");
        break;
      case AppLifecycleState.paused: //前台切后台
        print("paused");
        setState(() {
          player.pause();
        });
        break;
      case AppLifecycleState.detached:
        print("detached");
        break;
    }
  }

  double currentPos = 0.0;
  List<SrtRows> enSrtList = [];
  List<SrtRows> cnSrtList = [];
  SrtRows enSrt = new SrtRows();
  SrtRows cnSrt = new SrtRows();
  String enSrtText = "";
  String cnSrtText = "";
  Timer? seviceTimer;
  int currentPauseIndex = -1;

  bool startZimuPlay = false;

  void ChangePauseIndex(int index) async {

    await player.seekTo((enSrtList[index].TimeStartSecond! * 1000).toInt());

   // await player.seekTo(3000);

    setState(() {
      enSrt = enSrtList[index];
      enSrtText = enSrt.Text[0];
      currentPlayIndex = index;
      currentPauseIndex = index;
      startZimuPlay = true;
    });
    print(
        "enSrtList[index].TimeStartSecond ${enSrtList[index].TimeStartSecond} ${index}");
    //await player.seekTo((enSrtList[index].TimeStartSecond! * 1000).toInt());



    //player.setOption(FijkOption.playerCategory, "enable-accurate-seek", 3);
    //await player.setOption(FijkOption.playerCategory, "seek-at-start", 3);
    //var stopMilliseconds = (enSrtList[index].TimeEndSecond! * 1000).toInt() -
    //    (enSrtList[index].TimeStartSecond! * 1000).toInt();

    //print(
     //   "zimuDrawOpen-currentPos1 ${stopMilliseconds} ${enSrtList[index].TimeStartSecond} ${enSrtList[index].TimeEndSecond} pos: ${parsePos(player.currentPos.toString())} ${enSrtList[index].TimeStart} ${(enSrtList[index].TimeStartSecond! * 1000).toInt()}");
    /*Future.delayed(Duration(milliseconds: stopMilliseconds), () {
      print("ting");
      player.pause();
    });*/

  }

  void closeSeviceTimer() {
    if (seviceTimer != null) {
      seviceTimer?.cancel();
    }
  }

  Future ChangeCurrentCrt() async {
    var httpUtil = HttpUtil.getInstance();
    String cnSrtPath =
        _videoSourceTabs!.video![_curTabIdx]!.list![_curActiveIdx]!.cncrt!;
    String enSrtPath =
        _videoSourceTabs!.video![_curTabIdx]!.list![_curActiveIdx]!.encrt!;
    print("123 $_curTabIdx $_curActiveIdx $cnSrtPath",);
    if (cnSrtPath != "") {
      String cnRes = await httpUtil.getdata(cnSrtPath);

      setState(() {
        cnSrtList = SubtitleParse(cnRes);
      });
    }
    print("456");
    if (enSrtPath != "") {
      String enRes = await httpUtil.getdata(enSrtPath);
      print("enRes ${enRes}");
      enSrtList = SubtitleParse(enRes);
      setState(() {
        enSrtList = SubtitleParse(enRes);
      });
    }
  }

  void ChangeClickKw(index) async {
    setState(() {
      clickKw = index;
    });
  }

  // 钩子函数，用于更新状态
  void onChangeVideo(int curTabIdx, int curActiveIdx) async {

    this.setState(() async {
      _curTabIdx = curTabIdx;
      _curActiveIdx = curActiveIdx;
      clickKw = -1;
      await ChangeCurrentCrt();
    });

  }

  bool zimuDrawOpen = false;

  ChangeZimuDrawOpen(bool status) {
    if (status == true) {
      setState(() {
        player.pause();
      });
    }
    setState(() {
      zimuDrawOpen = status;
    });
  }

  createZimu() {
    setState(() {
      var found = false;
      for (var i = 0; i < enSrtList.length; i++) {
        if (currentPos >= enSrtList[i].TimeStartSecond! &&
            currentPos <= enSrtList[i].TimeEndSecond!) {
          enSrt = enSrtList[i];
          enSrtText = enSrt.Text[0];
          currentPlayIndex = i;
          found = true;
          break;
        }
      }
      if (!found) {
        enSrtText = "";
      }
      found = false;
      for (var i = 0; i < cnSrtList.length; i++) {
        if (currentPos >= cnSrtList[i].TimeStartSecond! &&
            currentPos <= cnSrtList[i].TimeEndSecond!) {
          cnSrt = cnSrtList[i];
          cnSrtText = cnSrt.Text[0];
          found = true;
          break;
        }
      }
      if (!found) {
        cnSrtText = "";
      }
    });
  }

  bool _prepared = false;
  bool _buffering = false;


  void changePrepared(bool prepared) async {
    _prepared = prepared;
  }

  Duration _bufferPos = Duration();

  void changeBuffering(bool buffering,Duration bufferPos,bool haveBuff) async {
      if (haveBuff){
        _buffering = buffering;
      }

      _bufferPos  = bufferPos;
  }

  initTimer() async {
    await ChangeCurrentCrt();
    print("wocao");
    const oneSec = const Duration(milliseconds: 300);

    var callback = (timer) {
      Wakelock.enable();

      currentPos = parsePos(player.currentPos.toString());

       if(zimuDrawOpen && currentPauseIndex != -1){
         print("enSrtList[currentPauseIndex].TimeEndSecond ${player.currentPos} ${enSrtList[currentPauseIndex].TimeEndSecond} ");
        if(player.value.state == FijkState.paused && startZimuPlay ){
          if(_prepared && !_buffering ){
            print("_prepared ${_prepared} ${_buffering} ${_bufferPos} ${parsePos(_bufferPos.toString())} ${enSrtList[currentPauseIndex].TimeEndSecond}");
            player.start();
          }

        }else{
          print(player.currentPos.toString());
          if(currentPos >= enSrtList[currentPauseIndex].TimeEndSecond!){
            if(startZimuPlay){
              player.pause();
              startZimuPlay = false;
              return;
            }
          }
        }
      }

      if (player.value.state != FijkState.started) {
        return;
      }
      createZimu();
    };

    if (seviceTimer == null) {
      seviceTimer = Timer.periodic(oneSec, callback);
    }
  }

  Future setOptions() async {
/*
    await player.setOption(FijkOption.playerCategory, "max-buffer-size", 100  * 1024);
    await player.setOption(FijkOption.playerCategory, "min-frames", 100);
    await player.setOption(FijkOption.playerCategory, "reconnect", 5);


    await  player.setOption(FijkOption.playerCategory, "start-on-prepared", 0);
    await  player.setOption(FijkOption.formatCategory, "http-detect-range-support", 0);
    await player.setOption(FijkOption.codecCategory, "skip_loop_filter", 0);
    await player.setOption(FijkOption.playerCategory, "soundtouch", 1);
*/


    //await player.setOption(FijkOption.playerCategory, "max-buffer-size", 100 * 1024);
    //await player.setOption(FijkOption.playerCategory, "min-frames", 100);
    //await player.setOption(FijkOption.playerCategory, "reconnect", 5);
    /*await player.setOption(FijkOption.playerCategory, "mediacodec", 1);
    await player.setOption(FijkOption.playerCategory, "framedrop", 5);
    await player.setOption(FijkOption.playerCategory, "skip_loop_filter", 48);
    await player.setOption(FijkOption.playerCategory, "probesize", 2048);//播放前的探测Size
    await player.setOption(FijkOption.playerCategory, "analyzeduration", 1);//

    await player.setOption(FijkOption.playerCategory, "http-detect-range-support", 0);
    await player.setOption(FijkOption.playerCategory, "analyzemaxduration", 100);
    await player.setOption(FijkOption.playerCategory, "flush_packets", 1);*/
    /*


    await player.setOption(FijkOption.playerCategory, "packet-buffering", 0);
    await player.setOption(FijkOption.playerCategory, "find_stream_info", 0);
    await player.setOption(FijkOption.playerCategory, "render-wait-start", 1);*/
  }

  @override
  void initState() {
    print("open");
    WidgetsBinding.instance!.addObserver(this);


    Future.delayed(
        Duration.zero,
            () => setState(() {
              setOptions();
        }));

    super.initState();

    // 格式化json转对象
    _videoSourceTabs = VideoSourceFormat.fromJson(widget.videoList);

    Future.delayed(
        Duration.zero,
        () => setState(() {
              print("initTimer");
              initTimer();
            }));

    // tabbar初始化
    _tabController = TabController(
      length: _videoSourceTabs!.video!.length,
      vsync: this,
    );
    _enKwtabController = TabController(
      length: 3,
      vsync: this,
    );
    // 这句不能省，必须有

  }

  // build 剧集
  Widget buildPlayDrawer() {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(24),
        child: AppBar(
          backgroundColor: Colors.black,
          automaticallyImplyLeading: false,
          primary: false,
          elevation: 0,
          title: TabBar(
            tabs: _videoSourceTabs!.video!
                .map((e) => Tab(text: e!.name!))
                .toList(),
            isScrollable: true,
            controller: _tabController,
          ),
        ),
      ),
      body: Container(
        color: Colors.black87,
        child: TabBarView(
          controller: _tabController,
          children: createTabConList(),
        ),
      ),
    );
  }



  // 剧集 tabCon
  List<Widget> createTabConList() {
    List<Widget> list = [];
    _videoSourceTabs!.video!.asMap().keys.forEach((int tabIdx) {
      List<Widget> playListBtns = _videoSourceTabs!.video![tabIdx]!.list!
          .asMap()
          .keys
          .map((int activeIdx) {
        return Padding(
          padding: EdgeInsets.all(5),
          child: ElevatedButton(
            style: ButtonStyle(
              shape: MaterialStateProperty.all(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
              elevation: MaterialStateProperty.all(0),
              backgroundColor: MaterialStateProperty.all(
                  tabIdx == _curTabIdx && activeIdx == _curActiveIdx
                      ? Colors.black
                      : Colors.black),
            ),
            onPressed: () async {
              setState(() {
                _curTabIdx = tabIdx;
                _curActiveIdx = activeIdx;
              });
              String nextVideoUrl =
                  _videoSourceTabs!.video![tabIdx]!.list![activeIdx]!.url!;
              // 切换播放源
              await player.stop();
              await player.reset();

              player.setDataSource(nextVideoUrl);
              await player.setOption(FijkOption.playerCategory, "soundtouch", 1);
              /*await player.setOption(FijkOption.playerCategory, "analyzeduration",1);
                await player.setOption(FijkOption.formatCategory,"probesize",1024*10);
              await player.setOption(FijkOption.formatCategory,"framedrop",5);
              await player.setOption(FijkOption.formatCategory,"max-buffer-size",1024*10);
              await player.setOption(FijkOption.formatCategory, "analyzemaxduration", 100);
             await player.setOption(FijkOption.formatCategory, "flush_packets", 1);
              await player.setOption(FijkOption.playerCategory, "packet-buffering",0);*/
             /* await player.setOption(FijkOption.playerCategory, "find_stream_info",0);
              await player.setOption(FijkOption.playerCategory, "render-wait-start",1);*/

            /*  await player.setOption(FijkOption.formatCategory, "cache_file_path","/storage/emulated/0/1.tmp");
              await player.setOption(FijkOption.formatCategory, "cache_map_path","/storage/emulated/0/2.tmp");
              await player.setOption(FijkOption.formatCategory, "parse_cache_map",1);
              await player.setOption(FijkOption.formatCategory, "auto_save_map",1);*/



              await player.setOption(FijkOption.formatCategory, "fflags", "fastseek");
              await player.setOption(FijkOption.playerCategory, "enable-accurate-seek", 1);
              //await player.setOption(FijkOption.playerCategory, "accurate-seek-timeout", 1);

              await player.prepareAsync();
              await player.start();
            /*  await player.setOption(FijkOption.playerCategory, "max-buffer-size", 100 *1024 * 1024);
              await player.setOption(FijkOption.playerCategory, "min-frames", 100);
              await player.setOption(FijkOption.playerCategory, "reconnect", 5);


              await player.setOption(FijkOption.formatCategory, "dns_cache_clear", 1);
              await player.setOption(FijkOption.playerCategory, "mediacodec", 0);
              await  player.setOption(FijkOption.playerCategory, "opensles", 0);

              await  player.setOption(FijkOption.playerCategory, "framedrop", 60);
              await  player.setOption(FijkOption.playerCategory, "start-on-prepared", 0);
              await  player.setOption(FijkOption.formatCategory, "http-detect-range-support", 0);
              await player.setOption(FijkOption.codecCategory, "skip_loop_filter", 0);
              await player.setOption(FijkOption.playerCategory, "soundtouch", 1);
*/
              /**
              await player.setOption(FijkOption.playerCategory, "mediacodec", 1);
              await player.setOption(FijkOption.playerCategory, "framedrop", 5);
              await player.setOption(FijkOption.playerCategory, "skip_loop_filter", 48);
              await player.setOption(FijkOption.playerCategory, "probesize", 2048);//播放前的探测Size
              await player.setOption(FijkOption.playerCategory, "analyzeduration", 1);//

              await player.setOption(FijkOption.playerCategory, "http-detect-range-support", 0);
              await player.setOption(FijkOption.playerCategory, "analyzemaxduration", 100);
              await player.setOption(FijkOption.playerCategory, "flush_packets", 1);*/
            },
            child: Text(
              _videoSourceTabs!.video![tabIdx]!.list![activeIdx]!.name!,
              style: TextStyle(
                color: Colors.white,
              ),
            ),
          ),
        );
      }).toList();
      //
      list.add(
        SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(left: 5, right: 5),
            child: Wrap(
              direction: Axis.horizontal,
              children: playListBtns,
            ),
          ),
        ),
      );
    });
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        FijkView(
          height: 260,
          color: Colors.black,
          fit: FijkFit.cover,
          player: player,
          onDispose: (FijkData f) => {},
          panelBuilder: (
            FijkPlayer player,
            FijkData data,
            BuildContext context,
            Size viewSize,
            Rect texturePos,
          ) {
            /// 使用自定义的布局
            return CustomFijkPanel(
                player: player,
                viewSize: viewSize,
                texturePos: texturePos,
                currentCtx: widget.currentCtx,
                // 标题 当前页面顶部的标题部分
                playerTitle: "标题",
                // 当前视频改变钩子
                onChangeVideo: onChangeVideo,
                // 当前视频源tabIndex
                curTabIdx: _curTabIdx,
                // 当前视频源activeIndex
                curActiveIdx: _curActiveIdx,
                // 显示的配置
                showConfig: v_cfg,
                // json格式化后的视频数据
                videoFormat: _videoSourceTabs,
                // tabController
                tabController: _tabController,
                enKwtabController: _enKwtabController,
                enSrtList: enSrtList,
                enSrtText: enSrtText,
                cnSrtText: cnSrtText,
                clickKw: clickKw,
                ChangeClickKw: ChangeClickKw,
                playMovie: widget.playMovie,
                currentPlayIndex: currentPlayIndex,
                ChangeZimuDrawOpen: ChangeZimuDrawOpen,
                ChangePauseIndex: ChangePauseIndex,
                changeBuffering:changeBuffering,
                changePrepared:changePrepared,
            );
          },
        ),
        // 请不要使用同一个tabbar，否则会卡顿，原因是数据更新导致整体重新绘制，
        // 可以使用_curTabIdx和_curActiveIdx手动渲染其他类似组件，判断
        // Container(
        //   height: 300,
        //   child: buildPlayDrawer(),
        // ),
        Container(
          child: Text(
              '当前tabIdx : ${_curTabIdx.toString()} 当前activeIdx : ${_curActiveIdx.toString()}'),
        )
      ],
    );
  }
}
