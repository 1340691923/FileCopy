import 'dart:async';
import 'dart:typed_data';


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:ifwang/pages/VideoDetailPage.dart';
import 'package:wakelock/wakelock.dart';

class Bofang extends StatefulWidget {
  Map<String, List<Map<String, dynamic>>> videoList = {};

  Bofang(this.videoList);



  @override
  BofangState createState() => BofangState();
}

class BofangState extends State<Bofang>  {

  bool playMovie = true;

  @override
  void initState() {
    Wakelock.enable();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // return VideoDetailPage();
    return WillPopScope(
      onWillPop: () async {
        return true;
      },
      child: Scaffold(
        body: Column(
          children: [
            Container(
              height: 24,
            ),
             VideoDetailPage(context, widget.videoList,playMovie),
          ],
        ),
      ),
    );
  }
}
