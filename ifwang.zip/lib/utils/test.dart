import 'package:flutter/material.dart';

const APPBAR_SCROLL_OFFSET = 100; //设置滑动变化的偏移量

List<Widget> _buildList(Map<String, List<Widget>> CityNames) {
  List<Widget> widgets = [];
  CityNames.keys.forEach((key) {
    widgets.add(_item(key, CityNames[key]!));
  });
  return widgets;
}

Widget _item(String city, List<Widget> subCities) {
  return ExpansionTile(
      children: subCities.map((subCity) => _buildSub(subCity)).toList(),
      title: Text(
        city,
        style: TextStyle(
          color: Colors.white,
          fontSize: 20,
        ),
      ));
}

Widget _buildSub(Widget subCity) {
  return FractionallySizedBox(
    widthFactor: 1,
    child: Container(
      height: 40,
      margin: EdgeInsets.only(bottom: 5, left: 12),
      //decoration: BoxDecoration(color: Colors.grey),
      child: subCity,
    ),
  );
}


Widget DanCiShiYi(Map<String, List<Widget>> CityNames) {

  return Container(
    margin:  EdgeInsets.fromLTRB(70, 0, 70, 0.0),
    color: Colors.grey.withOpacity(0.1),
    height: 800,

    child: ListView(
      children: _buildList(CityNames),
    ),
  );
}
