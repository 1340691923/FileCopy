import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

List<Stack> FuheText(String text,Color? colors,Function clickFunc){
  List<Stack> stacks = [];
  stacks.add(
      Stack(
        children: [
          GestureDetector(
            child:
            Text(text,
                softWrap: true,
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: TextStyle(
                  fontFamily: "Branch",
                  fontSize: 18,
                  foreground: Paint()
                    ..style = PaintingStyle.stroke
                    ..strokeWidth = 2
                    ..color = Colors.black,
                )),
            onTap: () {
              clickFunc();
            },
          ),
          GestureDetector(
            child: Text(
              text,
              softWrap: true,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: TextStyle(
                fontFamily: "Branch",
                fontSize: 18,
                color: colors,
              ),
            ),
            onTap: () {
              clickFunc();
            },
          )
        ],
      )
  );
  return stacks;
}