import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ifwang/utils/toast.dart';

class HttpUtil {
  static HttpUtil? instance;
  Dio? dio;
  BaseOptions? options;

  CancelToken cancelToken = new CancelToken();

  static HttpUtil getInstance() {
    if (null == instance) instance = new HttpUtil();
    return instance!;
  }

  /*
   * config it and create
   */
  HttpUtil() {
    //BaseOptions、Options、RequestOptions 都可以配置参数，优先级别依次递增，且可以根据优先级别覆盖参数
    options = new BaseOptions(
      //请求基地址,可以包含子路径
      baseUrl: "http://www.ycvod.net/report",
      //连接服务器超时时间，单位是毫秒.
      connectTimeout: 10000,
      //响应流上前后两次接受到数据的间隔，单位为毫秒。
      receiveTimeout: 5000,
      //Http请求头.
      headers: {
        //do something
        "version": "1.0.0"
      },
      //请求的Content-Type，默认值是"application/json; charset=utf-8",Headers.formUrlEncodedContentType会自动编码请求体.
      contentType: Headers.formUrlEncodedContentType,
      //表示期望以那种格式(方式)接受响应数据。接受4种类型 `json`, `stream`, `plain`, `bytes`. 默认值是 `json`,
      responseType: ResponseType.json,
    );

    dio = new Dio(options);

    //添加拦截器

    /*   dio?.interceptors.add(LogInterceptor(responseBody: true,
        requestBody: true,
        logPrint: (log) {
          LogUtil.init(isDebug: Const.DEBUG);
          LogUtil.v(log, tag: "");
          // ignore log
        }));*/
   /* dio?.interceptors.add(InterceptorsWrapper(onRequest: ((reqOpt, handler) {

      dio?.lock();
      Future<dynamic> future = Future(() async {
        return LocalStorage.get(UserInfo.X_TOKEN);
      });

      future.then((value) {
        if (value != null) {
          reqOpt.headers["X-TOKEN"] = value;
          return options;
        }
      }).whenComplete(() {
        dio?.unlock();
        handler.next(reqOpt);
      });
    }), onResponse: (response, handler) {
      handler.next(response);
    }));*/
  }

  /*
   * get请求
   */
  get(BuildContext context,url, {data, options, cancelToken}) async {
    Response? response;
    try {
      response = await dio?.get(url,
          queryParameters: data, options: options, cancelToken: cancelToken);
    } on DioError catch (e) {
      print('get error---------$e');
    }

    Map<String, dynamic> res = response?.data;

      if (res["code"] != 0) {
        var rbacAuthFail = { 40004: true, 40005: true };

        if (rbacAuthFail[res["code"]] != null) {
          Toast.toast(context,msg:res["msg"]);
          return res["data"];
        }

        var loginFail = { 40001: true, 40002: true, 40003: true };

        // 50008: Illegal token; 50012: Other clients logged in; 50014: Token expired;
        if (loginFail[res["code"]] != null) {
          // to re-login
         // LoginController.LoginOut(context);
          return "{}";
        }
        return res["data"];
        // return Promise.reject(new Error(res.msg || '未知错误'))
      } else {
        return res["data"];
      }

    return res["data"];
  }

  /*
   * error统一处理
   */
  void formatError(DioError e) {
    if (e.type == DioErrorType.connectTimeout) {
      // It occurs when url is opened timeout.
      print("连接超时");
    } else if (e.type == DioErrorType.sendTimeout) {
      // It occurs when url is sent timeout.
      print("请求超时");
    } else if (e.type == DioErrorType.receiveTimeout) {
      //It occurs when receiving timeout
      print("响应超时");
    } else if (e.type == DioErrorType.response) {
      // When the server response, but with a incorrect status, such as 404, 503...
      print("出现异常");
    } else if (e.type == DioErrorType.cancel) {
      // When the request is cancelled, dio will throw a error with this type.
      print("请求取消");
    } else {
      //DEFAULT Default error type, Some other Error. In this case, you can read the DioError.error if it is not null.
      print("未知错误");
    }
  }

  /*
   * post请求
   */
  post(url, {data, options, cancelToken}) async {
    Response? response;
    try {
      response = await dio?.post(url,
          queryParameters: data, options: options, cancelToken: cancelToken);
      print('post success---------${response?.data}');
    } on DioError catch (e) {
      print('post error---------$e');
      formatError(e);
    }
    return response?.data;
  }

  getdata(url)async{
    var res = await dio?.get(url);
    return res?.data;
  }
}
