import 'package:flutter/cupertino.dart';

class WeiIcons {
  static const IconData EnIcon = IconData(0xe629, fontFamily: 'iconfont');
  static const IconData CnIcon = IconData(0xe62a, fontFamily: 'iconfont');
  static const IconData ZiMuIcon = IconData(0xe601, fontFamily: 'iconfont');
}