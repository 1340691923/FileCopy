import 'package:audioplayers/audio_cache.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ifwang/utils/Const.dart';
import 'package:ifwang/utils/fuhe_text.dart';
import 'package:ifwang/utils/httputil.dart';
import 'package:ifwang/utils/icons.dart';
import 'package:ifwang/utils/toast.dart';
import 'package:audioplayers/audioplayers.dart';

double parsePos(String pos) {
  pos = pos.replaceAll(",", ".");
  var posArr = pos.split(":");
  if (posArr.length == 4) {
    posArr.removeAt(0);
  }

  double second = 0.0;
  for (var i = 0; i < posArr.length; i++) {
    var posStr = posArr[i];
    var pos = double.parse(posStr);
    if (i == 0) {
      second += pos * 3600;
    } else if (i == 1) {
      second += pos * 60;
    } else if (i == 2) {
      second += pos;
    }
  }
  return second;
}

var CN = 1;
var EN = 2;

String FiterOtherWd(String wd){

  return wd.replaceAll(RegExp(r'[#@￥%&*()-+!@#$%^&*()_+.=?!><}{|\:;*/[]'), "");
} 

List<Stack> getWords(BuildContext context, String words, int typ, Color bgColor,
    bool fullScreen, Function stopPlayFun,int clickKw,Function clickFunc) {
  List<Stack> stacks = [];

  var wordArr = words.split(" ");

  double showFontSize = 20;

  if (fullScreen) {
    if (typ == EN) {
      showFontSize = 25;
    }

    if (typ == CN) {
      showFontSize = 20;
    }
  } else {
    if (typ == EN) {
      showFontSize = 15;
    }

    if (typ == CN) {
      showFontSize = 10;
    }
  }

  wordArr.asMap().keys.forEach((index) {

    var style = TextStyle(
      fontFamily: typ==EN?"Branch":"ZhiYong",
      fontSize: showFontSize,
      foreground: Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = bgColor,
    );

    if (clickKw == index && typ == EN) {
      style = TextStyle(
          fontFamily: typ==EN?"Branch":"ZhiYong",
          fontSize: showFontSize,
          foreground: Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2
            ..color = bgColor,
          backgroundColor: Colors.blue);
    }

    stacks.add(
        Stack(
      children: [
        GestureDetector(
          child:
          Text(wordArr[index],
              softWrap: true,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
              style: style),
          onTap: () {
            if (!fullScreen || typ == CN) {
              return;
            }
            stopPlayFun(FiterOtherWd(wordArr[index]), index);
          },
        ),
        GestureDetector(
          child: Text(
            wordArr[index],
            softWrap: true,
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
            style: TextStyle(
              fontFamily: typ==EN?"Branch":"ZhiYong",
              fontSize: showFontSize,
              color: Colors.grey[300],
            ),
          ),
          onTap: () {
            if (!fullScreen || typ == CN) {
              return;
            }
            stopPlayFun(FiterOtherWd(wordArr[index]), index);
          },
        )
      ],
    )
    );
  });

  return stacks;
}



Widget buildSrt(BuildContext context, int typ, Color bgColor, String word,
    double bottom, bool fullScreen, Function stopPlayFun,int clickKw,Function clickFunc) {
  return Positioned(
      left: 0,
      right: 0,
      bottom: bottom,
      child: Container(
        height: 20,
        child: IndexedStack(
          // index: 50,
          children: [
            // 底部UI控制器
            Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: AnimatedOpacity(
                  opacity: 0.5,
                  duration: Duration(milliseconds: 400),
                  child: Container(
                    height: 20,
                    child: Stack(
                      // alignment:Alignment.center ,
                      children: <Widget>[
                        Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Flexible(child: Wrap(
                                spacing: 10.0,
                                runSpacing: 10.0,
                                children: getWords(context, word, typ, bgColor, fullScreen, stopPlayFun,clickKw,clickFunc),
                              ))
                            ],
                          ),
                          alignment: Alignment.center,
                          padding: EdgeInsets.only(left: 10, right: 10),
                        ),
                      ],
                    ),
                  ),
                )),
          ],
        ),
      ));
}

Widget buildMyFunc(bool fullScreen, double bottom,bool OpenChinese,bool OpenEn,Function ChangeFunc,Function ChangeZiMuFunc,bool _ziMuDrawerState,BuildContext context) {
  //!fullScreen?InkWell():

  List<Widget> stacks = [];

  stacks.add(AnimatedOpacity(
    opacity: 0.7,
    duration: Duration(milliseconds: 400),
    child: Align(
      alignment: Alignment.centerRight,
      child:
      Column(
        children: [
          Padding(

            padding: EdgeInsets.all(
                1
            ),
            child:
            InkWell(
              onTap: () {

              },
              child: Container(

                alignment: Alignment.center,
                width: 100,
                height: 30,
                child: Stack(
                  children: [
                    IconButton(
                      icon: Icon(WeiIcons.ZiMuIcon),
                      color:  _ziMuDrawerState?Colors.orange:Colors.blueAccent,
                      iconSize:  25.0,

                      splashColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onPressed: (){
                        print("_ziMuDrawerState $_ziMuDrawerState");
                        ChangeZiMuFunc(!_ziMuDrawerState);
                      },
                    )

                  ],
                  //children: FuheText( OpenEn?"开启英文":"屏蔽英文", ()=>{   ChangeFunc(2,!OpenEn)}),
                ),
              ),
            ),
          ),
          Padding(

            padding: EdgeInsets.all(
                1
            ),
            child:
            InkWell(
              onTap: () {

              },
              child: Container(

                alignment: Alignment.center,
                width: 100,
                height: 30,
                child: Stack(
                  children: [
                    IconButton(
                      icon: Icon(WeiIcons.EnIcon),
                      color:  OpenEn?Colors.blueAccent :Colors.orange,
                      iconSize:  25.0,

                      splashColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onPressed: (){
                        if(OpenEn){
                          Toast.toast(context,msg: "已经开启英文字幕");
                        }else{
                          Toast.toast(context,msg: "已经关闭英文字幕");
                        }
                        ChangeFunc(2,!OpenEn);

                      },
                    )

                  ],
                  //children: FuheText( OpenEn?"开启英文":"屏蔽英文", ()=>{   ChangeFunc(2,!OpenEn)}),
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(
                1
            ),
            child:
            InkWell(
              onTap: () {

              },
              child: Container(
                alignment: Alignment.center,
                width: 100,
                height: 30,
                child: Stack(
                   children: [
                     IconButton(
                       icon: Icon(WeiIcons.CnIcon),
                       color:  OpenChinese?Colors.blueAccent :Colors.orange,
                       iconSize:  25.0,

                       splashColor: Colors.transparent,
                       highlightColor: Colors.transparent,
                       onPressed: (){
                         if(OpenEn){
                           Toast.toast(context,msg: "已经开启中文字幕");
                         }else{
                           Toast.toast(context,msg: "已经关闭中文字幕");
                         }
                         ChangeFunc(1,!OpenChinese);
                       },
                     )
                   ],
                ),
              ),
            ),
          ),

        ],
      )
    ),
  ));

  return Positioned(
      //left: 0,
      left: 0,
      bottom: 50,
      child: !fullScreen
          ? Container()
          : Container(child: Stack(children: stacks)));
}

class SrtRows {
  int? Id;
  String? Number;
  String? TimeStart;
  String? TimeEnd;
  double? TimeStartSecond;
  double? TimeEndSecond;
  List<String> Text = [];

  Map<String, dynamic> toJson() => {
        'Id': Id,
        'Number': Number,
        "TimeStart": TimeStart,
        'TimeEnd': TimeEnd,
        'TimeStartSecond': TimeStartSecond,
        'TimeEndSecond': TimeEndSecond,
        'Text': Text,
      };
}

class RowInfo {
  String? rowText;
  int? rowType;

  RowInfo(this.rowText, this.rowType);
}

const PARSE_SRT_NUMBER = 1;
const PARSE_SRT_TIME_RANGE = 2;
const PARSE_SRT_SUBTITLE_TEXT = 3;
const PARSE_SRT_TRIM = 4;

RowInfo ParseSrtRows(String rowText, bool lineStart) {
  rowText = rowText.trim();
  var rowTextInt = int.tryParse(rowText);
  if (rowTextInt != 0 && lineStart == false) {
    return RowInfo(rowText, PARSE_SRT_NUMBER);
  }
  RegExp exp = new RegExp(
      r"((\d{1,2}:\d{1,2}:\d{1,2}[,|\.]\d{2,4})\s*-->\s*(\d{1,2}:\d{1,2}:\d{1,2}[,|\.]\d{2,4}))");
  if (exp.hasMatch(rowText)) {
    return RowInfo(rowText.split(" --> ").join("-"), PARSE_SRT_TIME_RANGE);
  }
  if (rowText != "") {
    return RowInfo(rowText, PARSE_SRT_SUBTITLE_TEXT);
  } else {
    return RowInfo(rowText, PARSE_SRT_TRIM);
  }
}

//字幕解析器
List<SrtRows> SubtitleParse(String srtData) {
  List<SrtRows> Rows = [];

  var lineRows = 0;
  var lineStart = false;
  var lineRowSrt = new SrtRows();

  var arr = srtData.split("\n");

  for (var i = 0; i < arr.length; i++) {
    String lineText = arr[i];
    RowInfo rowInfo = ParseSrtRows(lineText, lineStart);
    switch (rowInfo.rowType) {
      case PARSE_SRT_NUMBER:
        {
          lineRowSrt = new SrtRows();
          lineRowSrt.Id = lineRows;
          lineRowSrt.Number = rowInfo.rowText;
          lineStart = true;
        }
        break;
      case PARSE_SRT_TIME_RANGE:
        {
          var srtTimes = rowInfo.rowText!.split("-");
          lineRowSrt.TimeStart = srtTimes[0];
          lineRowSrt.TimeEnd = srtTimes[1];
        }
        break;
      case PARSE_SRT_SUBTITLE_TEXT:
        {
          lineRowSrt.Text.add(rowInfo.rowText!);
        }
        break;
      case PARSE_SRT_TRIM:
        {
          double fsecond = 0.0;
          if (lineStart == true) {
            if (lineRowSrt.TimeStart != "" &&
                lineRowSrt.TimeEnd != "" &&
                lineRowSrt.Text.length > 0) {
              fsecond = parsePos(lineRowSrt.TimeStart!);
              lineRowSrt.TimeStartSecond = fsecond;
              fsecond = parsePos(lineRowSrt.TimeEnd!);
              lineRowSrt.TimeEndSecond = fsecond;
              lineRows++;
              Rows.add(lineRowSrt);
            }
            lineStart = false;
          }
          break;
        }
    }
  }

  double fsecond = 0.0;
  if (lineStart == true) {
    if (lineRowSrt.TimeStart != "" &&
        lineRowSrt.TimeEnd != "" &&
        lineRowSrt.Text.length > 0) {
      fsecond = parsePos(lineRowSrt.TimeStart!);
      lineRowSrt.TimeStartSecond = fsecond;
      fsecond = parsePos(lineRowSrt.TimeEnd!);
      lineRowSrt.TimeEndSecond = fsecond;
      lineRows++;
      Rows.add(lineRowSrt);
    }
    lineStart = false;
  }

  return Rows;
}

//格式化时间
String Duration2String(Duration duration) {
  if (duration.inMilliseconds < 0) return "-: negtive";

  String twoDigits(int n) {
    if (n >= 10) return "$n";
    return "0$n";
  }

  String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
  String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
  int inHours = duration.inHours;
  return inHours > 0
      ? "$inHours:$twoDigitMinutes:$twoDigitSeconds"
      : "$twoDigitMinutes:$twoDigitSeconds";
}
