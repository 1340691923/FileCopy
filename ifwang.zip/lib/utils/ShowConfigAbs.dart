//显示状态
abstract class ShowConfigAbs {
  late bool nextBtn; //下一集按钮
  late bool speedBtn; //倍速按钮
  late bool drawerBtn; //抽屉按钮
  late bool lockBtn; //锁屏按钮
  late bool topBar; //展示播放器顶部
  late bool autoNext; //自动下一集
  late bool bottomPro; //底部进度
  late bool stateAuto;
}