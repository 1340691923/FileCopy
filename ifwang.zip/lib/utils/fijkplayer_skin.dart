import 'dart:async';
import 'dart:math';
import 'dart:ui';

import 'package:audioplayers/audioplayers.dart';
import 'package:fijkplayer/fijkplayer.dart';
import 'package:flutter/material.dart';
import 'package:ifwang/api/GetWord.dart';
import 'package:ifwang/main.dart';

import 'package:ifwang/utils/Const.dart';
import 'package:ifwang/utils/ShowConfigAbs.dart';
import 'package:ifwang/utils/buildGestureDetector.dart';
import 'package:ifwang/utils/fuhe_text.dart';
import 'package:ifwang/utils/httputil.dart';
import 'package:ifwang/utils/srt.dart';
import 'package:ifwang/utils/test.dart';
import 'package:ifwang/utils/test4.dart';
import 'package:ifwang/utils/toast.dart';
import 'package:wakelock/wakelock.dart';
import 'package:webview_flutter/webview_flutter.dart';

import './schema.dart' show VideoSourceFormat;
import './slider.dart' show NewFijkSliderColors, NewFijkSlider;

double speed = 1.0; //默认倍速
bool lockStuff = false; //默认是否锁屏
bool hideLockStuff = false;
final double barHeight = 50.0;
final double barFillingHeight =
    MediaQueryData.fromWindow(window).padding.top + barHeight; //bar的填充高度
final double barGap = barFillingHeight - barHeight;

class CustomFijkPanel extends StatefulWidget {
  final FijkPlayer player;
  final Size viewSize;
  final Rect texturePos;
  final BuildContext? currentCtx;
  final String playerTitle;
  final Function onChangeVideo;
  final int curTabIdx;
  final int curActiveIdx;
  final ShowConfigAbs showConfig;
  final VideoSourceFormat? videoFormat;
  final TabController tabController;
  final TabController enKwtabController;
  List<SrtRows> enSrtList;
  String enSrtText = "";
  String cnSrtText = "";
  SrtRows srtRows = new SrtRows();
  Function ChangeClickKw;
  int clickKw = -1;
  bool playMovie = true;
  int currentPlayIndex = 0;
  Function ChangeZimuDrawOpen;
  Function ChangePauseIndex;
  Function changePrepared;
  Function changeBuffering;

  CustomFijkPanel(
      {required this.player,
      required this.viewSize,
      required this.texturePos,
      this.currentCtx,
      this.playerTitle = "",
      required this.showConfig,
      required this.onChangeVideo,
      required this.videoFormat,
      required this.tabController,
      required this.curTabIdx,
      required this.curActiveIdx,
      required this.enKwtabController,
      required this.enSrtList,
      required this.enSrtText,
      required this.cnSrtText,
      required this.clickKw,
      required this.ChangeClickKw,
      required this.playMovie,
      required this.currentPlayIndex,
      required this.ChangeZimuDrawOpen,
      required this.ChangePauseIndex,
        required this.changeBuffering,
        required this.changePrepared,
      });

  @override
  _CustomFijkPanelState createState() => _CustomFijkPanelState();
}

class _CustomFijkPanelState extends State<CustomFijkPanel>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  //AutomaticKeepAliveClientMixin 避免重复 initstate   TickerProviderStateMixin 监听每一帧的动画
  FijkPlayer get player => widget.player;

  ShowConfigAbs get showConfig => widget.showConfig;

  VideoSourceFormat get _videoSourceTabs => widget.videoFormat!;

  TabController get _tabController => widget.tabController;

  ScrollController? ZiMuAnimationController;

  // VideoSourceFormat? _videoSourceTabs;
  // late TabController _tabController;

  bool _lockStuff = lockStuff;
  bool _hideLockStuff = hideLockStuff;
  bool _drawerState = false;
  bool _enKwDrawerState = false;
  bool _ziMuDrawerState = false;
  bool closeChinese = false;
  bool closeEn = false;

  void ChangeChineseFlag(int typ, bool b) {
    if (typ == 1) {
      setState(() {
        closeChinese = b;
      });
    } else {
      setState(() {
        closeEn = b;
      });
    }
  }

  Timer? _hideLockTimer;

  FijkState? _playerState;

  String clickKeyWord = "";

  StreamSubscription? _currentPosSubs;

  AnimationController? _animationController;

  Animation<Offset>? _animation;

  void initEvent() async {
    print("initEvent");

    ZiMuAnimationController = ScrollController();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 280),
      vsync: this,
    );

    print("currentPlayIndex ${widget.currentPlayIndex} ");

    // init animation
    _animation = Tween(
      begin: Offset(1, 0),
      end: Offset.zero,
    ).animate(_animationController!);
    // is not null
    if (_videoSourceTabs.video!.length < 1) return null;
    // init plater state
    setState(() {
      _playerState = player.value.state;
    });
    player.addListener(_playerValueChanged);
    print("widget.playMovie ${widget.playMovie}");
    if (widget.playMovie) {
      player.start();
    } else {
      //player.pause();
    }
  }

  @override
  void initState() {
    super.initState();
    initEvent();
  }

  @override
  void dispose() {
    _currentPosSubs?.cancel();
    _hideLockTimer?.cancel();
    // _tabController.dispose();
    player.removeListener(_playerValueChanged);
    _animationController!.dispose();
    Wakelock.disable();
    super.dispose();
  }

  Map<String, dynamic> wordParse = {};

  //点击单词后
  stopPlayFun(String kw, int index) async {
    var word = await Word.getWordParse(widget.currentCtx!, kw);
    print("word ${kw} ${word}");
    //Toast.toast(widget.currentCtx!, msg: kw);
    setState(() {
      wordParse = word;
      widget.ChangeClickKw(index);

      clickKeyWord = kw;
    });
    changeEnKwDrawerState(true);
    player.pause();
  }

  // 获得播放器状态
  _playerValueChanged() {
    setState(() {
      _playerState = player.value.state;
    });
  }

  // 切换UI 播放列表显示状态
  void changeDrawerState(bool state) {
    if (state) {
      setState(() {
        _drawerState = state;
      });
    }
    Future.delayed(Duration(milliseconds: 100), () {
      _animationController!.forward();
    });
  }

  // 切换UI 单词详情显示状态
  void changeEnKwDrawerState(bool state) {
    if (state) {
      setState(() {
        _enKwDrawerState = state;
      });
    }
    Future.delayed(Duration(milliseconds: 100), () {
      _animationController!.forward();
    });
  }

  // 抽屉组件 - 单词详情
  Widget _buildEnKeywordListDrawer() {
    return Container(
      alignment: Alignment.centerRight,
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () async {
                await _animationController!.reverse();
                setState(() {
                  _enKwDrawerState = false;
                  widget.ChangeClickKw(-1);
                  player.start();
                });
              },
            ),
          ),
          Container(
            child: SlideTransition(
              position: _animation!,
              child: Container(
                color: Colors.black45.withOpacity(.9),
                height: window.physicalSize.height,
                width: MediaQuery.of(context).size.width,
                //child: Container(),
                child: _buildEnKeywordDrawer(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // build 单词
  Widget _buildEnKeywordDrawer() {
    return Stack(
      children: [
        CustomTabBarView(clickKeyWord, wordParse),
        Positioned(
          child: Column(
            children: [
              IconButton(
                iconSize: 30,
                onPressed: () async {
                  await _animationController!.reverse();
                  setState(() {
                    _enKwDrawerState = false;
                    widget.ChangeClickKw(-1);
                    player.start();
                  });
                },
                icon: Icon(Icons.close),
                color: Colors.white,
              ),
              IconButton(
                iconSize: 30,
                onPressed: () async {
                  print("123");
                  Toast.toast(widget.currentCtx!, msg: "成功加入生词卡中");
                  print("123");
                },
                icon: Icon(Icons.add_alarm),
                color: Colors.white,
              )
            ],
          ),
        ),
      ],
    );
  }

  bool openEnKwDrawer() {
    return _enKwDrawerState;
  }

  /////
  // 切换UI 单词详情显示状态
  void changeZiMuDrawerState(bool state) {

    if (state) {
      setState(() {
        hideStuff = true;
      });
    }
    widget.ChangeZimuDrawOpen(state);
    setState(() {
      _ziMuDrawerState = state;
    });
    Future.delayed(Duration(milliseconds: 100), () {
      _animationController!.forward();
    });
  }

  // 抽屉组件 - 单词详情
  Widget _buildZiMuListDrawer() {
    return Container(
      // alignment: Alignment.centerRight,
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () async {
                await _animationController!.reverse();
                setState(() {
                  widget.ChangeZimuDrawOpen(false);
                  _ziMuDrawerState = false;
                });
              },
            ),
          ),
          Container(
            child: SlideTransition(
              position: _animation!,
              child: Container(
                color: Colors.transparent,
                height: window.physicalSize.height,
                width: MediaQuery.of(context).size.width,
                child: _buildZiMuDrawer(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  int scrollIndex = -1;
  bool hideStuff = false;
  // build 单词
  Widget _buildZiMuDrawer() {
    print("widget.currentPlayIndex ${widget.currentPlayIndex}");
    if (ZiMuAnimationController!.hasClients) {
      ZiMuAnimationController!.animateTo((widget.currentPlayIndex * 45),
          duration: Duration(milliseconds: 200), curve: Curves.linear);
    }

    return Row(
      children: [
        Expanded(
            child: Column(
          children: [

            IconButton(
              iconSize: 30,
              onPressed: () async {
                print("123");
                Toast.toast(widget.currentCtx!, msg: "截取视频片段");
                print("123");
              },
              icon: Icon(Icons.movie_creation),
              color: Colors.white,
            ),
            IconButton(
              iconSize: 30,
              onPressed: () async {
                print("123");
                Toast.toast(widget.currentCtx!, msg: "下一个句子");
                print("123");
              },
              icon: Icon(Icons.skip_next),
              color: Colors.white,
            )
          ],
        )),
        Container(
            //  color: Colors.grey.withOpacity(0.1),
            width: MediaQuery.of(context).size.width - 70,
            child:
              GestureDetector(child: ListWheelScrollView.useDelegate(
                perspective: 0.0028,
                onSelectedItemChanged: (index){
                  print("onSelectedItemChanged $index");
                  setState(() {
                    scrollIndex = index;
                  });
                },
               //   controller: ZiMuAnimationController,
                diameterRatio: 2.0,
                itemExtent: 45,
                childDelegate:
                ListWheelChildBuilderDelegate(
                    builder: (context, index) {
                      return
                        Container(
                          alignment: Alignment.centerRight,
                          child:ListTile(
                            trailing: Icon( Icons.play_circle_filled, color: widget.currentPlayIndex == index? Colors.red:scrollIndex == index?Colors.blue:Colors.white, size: 50),
                            title:  Row(
                              children: [
                                Stack(
                                    children: widget.currentPlayIndex == index
                                        ? FuheText(
                                      "${widget.enSrtList[index].Text[0]}   ",
                                      Colors.red,
                                          () => {print(111)},
                                    )
                                        :scrollIndex == index?
                                    FuheText(
                                      "${widget.enSrtList[index].Text[0]}  ",
                                      Colors.blue,
                                          () => {print(111)},
                                    )
                                        : FuheText(
                                      "${widget.enSrtList[index].Text[0]}   ",
                                      Colors.white,
                                          () => {print(111)},
                                    )),

                              ],
                            ),
                            /*subtitle:   Row(
                        children: [
                          Stack(
                              children: widget.currentPlayIndex == index
                                  ? FuheText(
                                " ${widget.enSrtList[index].TimeStart}",
                                Colors.red,
                                    () => {print(111)},
                              )
                                  :scrollIndex == index?
                              FuheText(
                                "   ${widget.enSrtList[index].TimeStart}",
                                Colors.blue,
                                    () => {print(111)},
                              )

                                  : FuheText(
                                "   ${widget.enSrtList[index].TimeStart}",
                                Colors.white,
                                    () => {print(111)},
                              )),

                        ],
                      ),*/
                          ),
                        );
                    },
                    childCount: widget.enSrtList.length),
              ),onTap: (){
                widget.ChangePauseIndex(scrollIndex);
              },)
             /*GestureDetector(child:
             ListWheelScrollView.useDelegate(
              onSelectedItemChanged: (index){
                print("onSelectedItemChanged $index");
                setState(() {
                  scrollIndex = index;
                });
              },
              controller: ZiMuAnimationController,
              diameterRatio: 2.0,
              itemExtent: 45,
              childDelegate:
               ListWheelChildBuilderDelegate(
                  builder: (context, index) {
                    return Container(
                        alignment: Alignment.centerRight,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              child: Row(
                                children: [
                                  Stack(
                                      children: widget.currentPlayIndex == index
                                          ? FuheText(
                                        "${widget.enSrtList[index].Text[0]}   ${widget.enSrtList[index].TimeStart}",
                                        Colors.red,
                                            () => {print(111)},
                                      )
                                          : FuheText(
                                        "${widget.enSrtList[index].Text[0]}   ${widget.enSrtList[index].TimeStart}",
                                        Colors.white,
                                            () => {print(111)},
                                      )),
                                  IconButton(
                                    icon: Icon(
                                      Icons.play_circle_filled,
                                      color: Colors.orange,
                                    ),
                                    onPressed: () {

                                    },
                                  )
                                ],
                              ),
                            ),
                          ],
                      ),
                    );
                  },
                  childCount: widget.enSrtList.length),
            ),onTap: (){
              print("scrollIndex $scrollIndex");
              widget.ChangePauseIndex(scrollIndex);
            })*/

            /*   ListView(children: [
              Text("1234"),
              Text("1234"),
              Text("1234"),
              Text("1234"),
              Text("1234"),
              Text("1234"),
              Text("1234"),

            ],)*/

            /*ListView.separated(
              itemCount: 10,
              itemBuilder: (context, i) {
                return new ListTile(
                  title:  Text("123",style: TextStyle(color: Colors.red),),
                  subtitle: Center(child: Text("456",style: TextStyle(color: Colors.red),),),
                  trailing: new Icon(Icons.play_circle_filled,color: Colors.red,),
                );
              },
            separatorBuilder: (BuildContext context, int index) {
              return Divider(color: Colors.white.withOpacity(0.2));
          },),*/
            ),
      ],
    );
  }

  bool openZiMuDrawer() {
    return _ziMuDrawerState;
  }

  ////

  // 切换UI lock显示状态
  void changeLockState(bool state) {
    setState(() {
      _lockStuff = state;
      if (state == true) {
        _hideLockStuff = true;
        _cancelAndRestartLockTimer();
      }
    });
  }

  bool showCN = false;

  // 切换UI lock显示状态
  void changeShowCN(bool state) {
    setState(() {
      _lockStuff = state;
      if (state == true) {
        _hideLockStuff = true;
        _cancelAndRestartLockTimer();
      }
    });
  }

  // 切换播放源
  Future<void> changeCurPlayVideo(int tabIdx, int activeIdx) async {
    await player.stop();
    player.reset().then((_) async {
      String curTabActiveUrl =
          _videoSourceTabs.video![tabIdx]!.list![activeIdx]!.url!;


     await player.setDataSource(
        curTabActiveUrl,
      );
      await player.setOption(FijkOption.playerCategory, "soundtouch", 1);
      /* await player.setOption(FijkOption.playerCategory, "analyzeduration",1);
      await player.setOption(FijkOption.formatCategory,"probesize",1024*10);
      await player.setOption(FijkOption.formatCategory,"framedrop",5);
      await player.setOption(FijkOption.formatCategory,"max-buffer-size",1024*10);
      await player.setOption(FijkOption.formatCategory, "analyzemaxduration", 100);
      await player.setOption(FijkOption.formatCategory, "flush_packets", 1);
      await player.setOption(FijkOption.playerCategory, "packet-buffering",0);*/
      /*await player.setOption(FijkOption.playerCategory, "find_stream_info",0);
      await player.setOption(FijkOption.playerCategory, "render-wait-start",1);*/
  /*    await player.setOption(FijkOption.formatCategory, "cache_file_path","/storage/emulated/0/1.tmp");
      await player.setOption(FijkOption.formatCategory, "cache_map_path","/storage/emulated/0/2.tmp");
      await player.setOption(FijkOption.formatCategory, "parse_cache_map",1);
      await player.setOption(FijkOption.formatCategory, "auto_save_map",1);*/


      await player.setOption(FijkOption.formatCategory, "fflags", "fastseek");
      await player.setOption(FijkOption.playerCategory, "enable-accurate-seek", 1);
     // await player.setOption(FijkOption.playerCategory, "accurate-seek-timeout", 1);



      player.prepareAsync();
      widget.onChangeVideo(tabIdx, activeIdx);
      await player.start();
    /*  await player.setOption(FijkOption.playerCategory, "max-buffer-size", 100 *1024 * 1024);
      await player.setOption(FijkOption.playerCategory, "min-frames", 100);
      await player.setOption(FijkOption.playerCategory, "reconnect", 5);


      await player.setOption(FijkOption.formatCategory, "dns_cache_clear", 1);
      await player.setOption(FijkOption.playerCategory, "mediacodec", 0);
      await  player.setOption(FijkOption.playerCategory, "opensles", 0);

      await  player.setOption(FijkOption.playerCategory, "framedrop", 60);
      await  player.setOption(FijkOption.playerCategory, "start-on-prepared", 0);
      await  player.setOption(FijkOption.formatCategory, "http-detect-range-support", 0);
      await player.setOption(FijkOption.codecCategory, "skip_loop_filter", 0);
      await player.setOption(FijkOption.playerCategory, "soundtouch", 1);*/
      /**
      await player.setOption(FijkOption.playerCategory, "mediacodec", 1);
      await player.setOption(FijkOption.playerCategory, "framedrop", 5);
      await player.setOption(FijkOption.playerCategory, "skip_loop_filter", 48);
      await player.setOption(FijkOption.playerCategory, "probesize", 2048);//播放前的探测Size
      await player.setOption(FijkOption.playerCategory, "analyzeduration", 1);//

      await player.setOption(FijkOption.playerCategory, "http-detect-range-support", 0);
      await player.setOption(FijkOption.playerCategory, "analyzemaxduration", 100);
      await player.setOption(FijkOption.playerCategory, "flush_packets", 1);*/
      // 回调

    });
  }

  void _cancelAndRestartLockTimer() {
    if (_hideLockStuff == true) {
      _startHideLockTimer();
    }
    setState(() {
      _hideLockStuff = !_hideLockStuff;
    });
  }

  void _startHideLockTimer() {
    _hideLockTimer?.cancel();
    _hideLockTimer = Timer(const Duration(seconds: 5), () {
      setState(() {
        _hideLockStuff = true;
      });
    });
  }

  // 锁 组件
  Widget _buidLockStateDetctor() {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _cancelAndRestartLockTimer,
      child: Container(
          child: Stack(
        children: [
          AnimatedOpacity(
            opacity: _hideLockStuff ? 0.0 : 0.7,
            duration: Duration(milliseconds: 400),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 20,
                  top: showConfig.stateAuto && !player.value.fullScreen
                      ? barGap
                      : 0,
                ),
                child: IconButton(
                  iconSize: 30,
                  onPressed: () {
                    setState(() {
                      _lockStuff = false;
                      _hideLockStuff = true;
                    });
                  },
                  icon: Icon(Icons.lock_open),
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      )),
    );
  }

  // 返回按钮
  Widget _buildTopBackBtn() {
    return Container(
      height: barHeight,
      alignment: Alignment.centerLeft,
      child: IconButton(
        icon: Icon(Icons.arrow_back),
        padding: EdgeInsets.only(
          left: 10.0,
          right: 10.0,
        ),
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
        color: Colors.white,
        onPressed: () {
          // 判断当前是否全屏，如果全屏，退出
          if (widget.player.value.fullScreen) {
            player.exitFullScreen();
          } else {
            if (widget.currentCtx == null) return null;
            player.stop();
            Navigator.pop(widget.currentCtx!);
          }
        },
      ),
    );
  }

  // 错误状态
  Widget _buildErrorContext() {
    return Center(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: showConfig.stateAuto && !widget.player.value.fullScreen
                ? barGap
                : 0,
          ),
          // 失败图标
          Icon(
            Icons.error,
            size: 50,
            color: Colors.white,
          ),
          // 错误信息
          Text(
            "播放失败，您可以点击重试！",
            style: TextStyle(
              color: Colors.white,
              fontSize: 15,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 5),
          // 重试
          ElevatedButton(
            style: ButtonStyle(
              shape: MaterialStateProperty.all(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              elevation: MaterialStateProperty.all(0),
              backgroundColor: MaterialStateProperty.all(Colors.white),
            ),
            onPressed: () {
              // 切换视频
              changeCurPlayVideo(widget.curTabIdx, widget.curActiveIdx);
            },
            child: Text(
              "点击重试",
              style: TextStyle(color: Colors.black),
            ),
          ),
        ],
      ),
    );
  }

  // 播放错误状态
  Widget _buildErrorWidget() {
    return Container(
      color: Colors.black,
      child: Stack(
        children: [
          showConfig.topBar
              ? Positioned(
                  left: 0,
                  top: 0,
                  child: Container(
                    height:
                        showConfig.stateAuto && !widget.player.value.fullScreen
                            ? barFillingHeight
                            : barHeight,
                    alignment: Alignment.bottomLeft,
                    child: _buildTopBackBtn(),
                  ),
                )
              : Container(),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            top: 0,
            child: _buildErrorContext(),
          )
        ],
      ),
    );
  }

  // 抽屉组件 - 播放列表
  Widget _buildPlayerListDrawer() {
    return Container(
      alignment: Alignment.centerRight,
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () async {
                await _animationController!.reverse();
                setState(() {
                  _drawerState = false;
                });
              },
            ),
          ),
          Container(
            child: SlideTransition(
              position: _animation!,
              child: Container(
                height: window.physicalSize.height,
                width: 320,
                child: _buildPlayDrawer(),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // build 剧集
  Widget _buildPlayDrawer() {
    return DefaultTabController(
      length: _videoSourceTabs.video!.length,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black87,
          automaticallyImplyLeading: false,
          elevation: 0.1,
          title: TabBar(
            tabs: _videoSourceTabs.video!
                .map((e) => Tab(text: e!.name!))
                .toList(),
            isScrollable: true,
            controller: _tabController,
          ),
        ),
        body: Container(
          child: TabBarView(
            controller: _tabController,
            children: _createTabConList(),
          ),
          color: Colors.black.withOpacity(0.8),
        ),
      ),
    );
  }

  // 剧集 tabCon
  List<Widget> _createTabConList() {
    List<Widget> list = [];
    _videoSourceTabs.video!.asMap().keys.forEach((int tabIdx) {
      List<Widget> playListBtns = _videoSourceTabs.video![tabIdx]!.list!
          .asMap()
          .keys
          .map((int activeIdx) {
        return Padding(
          padding: EdgeInsets.all(5),
          child: ElevatedButton(
            style: ButtonStyle(
              shape: MaterialStateProperty.all(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
              elevation: MaterialStateProperty.all(0),
              backgroundColor: MaterialStateProperty.all(
                  tabIdx == widget.curTabIdx && activeIdx == widget.curActiveIdx
                      ? Colors.deepOrange
                      : Colors.blue),
            ),
            onPressed: () {
              int newTabIdx = tabIdx;
              int newActiveIdx = activeIdx;
              // 切换播放源
              changeCurPlayVideo(newTabIdx, newActiveIdx);
            },
            child: Text(
              _videoSourceTabs.video![tabIdx]!.list![activeIdx]!.name!,
              style: TextStyle(
                color: Colors.white,
              ),
            ),
          ),
        );
      }).toList();
      //
      list.add(
        SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(left: 5, right: 5),
            child: Wrap(
              direction: Axis.horizontal,
              children: playListBtns,
            ),
          ),
        ),
      );
    });
    return list;
  }

  bool openDrawer() {
    return _drawerState;
  }

  bool lockPinmu() {
    return _lockStuff;
  }

  @override
  // ignore: must_call_super
  Widget build(BuildContext context) {
    Rect rect = player.value.fullScreen
        ? Rect.fromLTWH(
            0,
            0,
            widget.viewSize.width,
            widget.viewSize.height,
          )
        : Rect.fromLTRB(
            max(0.0, widget.texturePos.left),
            max(0.0, widget.texturePos.top),
            min(widget.viewSize.width, widget.texturePos.right),
            min(widget.viewSize.height, widget.texturePos.bottom),
          );

    List<Widget> ws = [];

    if (_playerState != FijkState.error) {
      //如果锁了的话 并且全屏
      if (lockPinmu() && showConfig.lockBtn && widget.player.value.fullScreen) {
        ws.add(
          _buidLockStateDetctor(),
        );
        //否则抽屉打开的话
      } else if (openDrawer() && widget.player.value.fullScreen) {
        ws.add(
          _buildPlayerListDrawer(),
        );
      } else if (!openEnKwDrawer()) {
        ws.add(
          buildGestureDetector(
            curActiveIdx: widget.curActiveIdx,
            curTabIdx: widget.curTabIdx,
            onChangeVideo: widget.onChangeVideo,
            player: widget.player,
            texturePos: widget.texturePos,
            showConfig: widget.showConfig,
            currentCtx: widget.currentCtx,
            playerTitle: widget.playerTitle,
            viewSize: widget.viewSize,
            videoFormat: widget.videoFormat,
            tabController: widget.tabController,
            changeDrawerState: changeDrawerState,
            changeLockState: changeLockState,
              hideStuff:hideStuff,
            changeBuffering:widget.changeBuffering,
            changePrepared:widget.changePrepared,
          ),
        );
      }
    }

    if (openEnKwDrawer() && widget.player.value.fullScreen) {
      ws.add(
        _buildEnKeywordListDrawer(),
      );
    }



    if (!closeEn && widget.clickKw == -1) {
      ws.add(buildSrt(
          context,
          EN,
          Color.fromRGBO(0, 0, 0, 1),
          widget.enSrtText,
          60,
          widget.player.value.fullScreen,
          stopPlayFun,
          widget.clickKw,
          widget.ChangeClickKw));
    }

    if (!closeChinese && widget.clickKw == -1) {
      ws.add(buildSrt(
          context,
          CN,
          Color.fromRGBO(0, 0, 0, 1),
          widget.cnSrtText,
          30,
          widget.player.value.fullScreen,
          stopPlayFun,
          widget.clickKw,
          widget.ChangeClickKw));
    }

    if (_ziMuDrawerState) {
      ws.add(
        _buildZiMuListDrawer(),
      );
    }

    ws.addAll([
      buildMyFunc(widget.player.value.fullScreen, 30, closeChinese, closeEn,
          ChangeChineseFlag, changeZiMuDrawerState,_ziMuDrawerState,widget.currentCtx!),
    ]);

    if(_playerState == FijkState.error){
      ws.add(
        _buildErrorWidget(),
      );
    }


    return WillPopScope(
      child: Positioned.fromRect(
        rect: rect,
        child: Stack(
          children: ws,
        ),
      ),
      onWillPop: () async {
        if (!widget.player.value.fullScreen) widget.player.stop();
        return true;
      },
    );
  }

  @override
  bool get wantKeepAlive => true;
}
