
///
/// des:
///
class SubtitleEntry {
  SubtitleEntry(this.time, this.content);

  ///
  /// 时间,格式：00:12
  ///
  final String time;

  ///
  /// 歌词
  ///
  final String content;
}