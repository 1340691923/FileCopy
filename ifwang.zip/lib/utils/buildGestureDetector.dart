
// ignore: camel_case_types
import 'dart:async';
import 'dart:math';

import 'package:fijkplayer/fijkplayer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ifwang/utils/ShowConfigAbs.dart';
import 'package:ifwang/utils/fijkplayer_skin.dart';
import 'package:ifwang/utils/schema.dart';
import 'package:ifwang/utils/slider.dart';

class buildGestureDetector extends StatefulWidget {

  final FijkPlayer player;
  final Size viewSize;
  final Rect texturePos;
  final BuildContext? currentCtx;
  final String playerTitle;
  final Function onChangeVideo;
  final int curTabIdx;
  final int curActiveIdx;
  final Function changeDrawerState;
  final Function changeLockState;

  final ShowConfigAbs showConfig;
  final VideoSourceFormat? videoFormat;
  final TabController tabController;
  Function changePrepared;
  Function changeBuffering;
  // 每次重绘的时候，设置显示
  bool hideStuff = false;

  buildGestureDetector({
    Key? key,
    required this.player,
    required this.viewSize,
    required this.texturePos,
    this.currentCtx,
    this.playerTitle = "",
    required this.showConfig,
    required this.onChangeVideo,
    required this.curTabIdx,
    required this.curActiveIdx,
    required this.videoFormat,
    required this.tabController,
    required this.changeDrawerState,
    required this.changeLockState,
    required this.hideStuff,
    required this.changePrepared,
    required this.changeBuffering
  }) : super(key: key);

  @override
  buildGestureDetectorState createState() =>
      buildGestureDetectorState(this.hideStuff);
}

// ignore: camel_case_types
class buildGestureDetectorState extends State<buildGestureDetector> {
  FijkPlayer get player => widget.player;

  ShowConfigAbs get showConfig => widget.showConfig;

  VideoSourceFormat get _videoSourceTabs => widget.videoFormat!;

  Duration _duration = Duration();
  Duration _currentPos = Duration();
  Duration _bufferPos = Duration();

  // 滑动后值
  Duration _dargPos = Duration();

  bool _isTouch = false;

  bool _playing = false;
  bool _prepared = false;
  String? _exception;

  double? updatePrevDx;
  double? updatePrevDy;
  int? updatePosX;

  bool? isDargVerLeft;

  double? updateDargVarVal;

  bool varTouchInitSuc = false;

  bool _buffering = false;

  double _seekPos = -1.0;

  StreamSubscription? _currentPosSubs;
  StreamSubscription? _bufferPosSubs;
  StreamSubscription? _bufferingSubs;

  Timer? _hideTimer;
  bool hideStuff = true;

  bool _hideSpeedStu = true;
  double _speed = speed;

  bool _isHorizontalMove = false;



  Map<String, double> speedList = {
    "2.0": 2.0,
    "1.8": 1.8,
    "1.5": 1.5,
    "1.2": 1.2,
    "1.0": 1.0,
    "0.5": 0.5,
  };

  // 初始化构造函数
  buildGestureDetectorState(this.hideStuff);

  Future<void> initEvent() async {
    // 设置初始化的值，全屏与半屏切换后，重设
    setState(() {
      _speed = speed;
    });
    // is not null
    if (_videoSourceTabs.video!.length < 1) return null;
    // url
    String url = _videoSourceTabs
        .video![widget.curTabIdx]!.list![widget.curActiveIdx]!.url!;

    print("encrt ${_videoSourceTabs.video![widget.curTabIdx]!.list![widget.curActiveIdx]!.encrt!}");

    await player.setDataSource(
      url,

    );

    await player.setOption(FijkOption.playerCategory, "soundtouch", 1);
    /* await player.setOption(FijkOption.playerCategory, "analyzeduration",1);
      await player.setOption(FijkOption.formatCategory,"probesize",1024*10);
    await player.setOption(FijkOption.formatCategory,"framedrop",5);
    await player.setOption(FijkOption.formatCategory,"max-buffer-size",1024*10);
    await player.setOption(FijkOption.formatCategory, "analyzemaxduration", 100);
    await player.setOption(FijkOption.formatCategory, "flush_packets", 1);
    await player.setOption(FijkOption.playerCategory, "packet-buffering",0);*/
 /*   await player.setOption(FijkOption.playerCategory, "find_stream_info",0);
    await player.setOption(FijkOption.playerCategory, "render-wait-start",1);*/
/*    await player.setOption(FijkOption.formatCategory, "cache_file_path","/storage/emulated/0/1.tmp");
    await player.setOption(FijkOption.formatCategory, "cache_map_path","/storage/emulated/0/2.tmp");
    await player.setOption(FijkOption.formatCategory, "parse_cache_map",1);
    await player.setOption(FijkOption.formatCategory, "auto_save_map",1);*/


    await player.setOption(FijkOption.formatCategory, "fflags", "fastseek");
    await player.setOption(FijkOption.playerCategory, "enable-accurate-seek", 1);
    //await player.setOption(FijkOption.playerCategory, "accurate-seek-timeout", 1);
    await player.prepareAsync();
    await player.start();
    print("test");

    // 延时隐藏
    _startHideTimer();
  }

  @override
  void dispose() {
    super.dispose();
    _hideTimer?.cancel();

    player.removeListener(_playerValueChanged);
    _currentPosSubs?.cancel();
    _bufferPosSubs?.cancel();
    _bufferingSubs?.cancel();
  }

  @override
  void initState() {
    super.initState();

    initEvent();

    _duration = player.value.duration;
    _currentPos = player.currentPos;
    _bufferPos = player.bufferPos;
    _prepared = player.state.index >= FijkState.prepared.index;

    widget.changePrepared(_prepared);

    _playing = player.state == FijkState.started;
    _exception = player.value.exception.message;
    _buffering = player.isBuffering;

    widget.changeBuffering(_buffering,_bufferPos,true);

    player.addListener(_playerValueChanged);

    _currentPosSubs = player.onCurrentPosUpdate.listen((v) {
      setState(() {
        //print("_currentPosSubs $_currentPosSubs");
        _currentPos = v;
      });
    });

    _bufferPosSubs = player.onBufferPosUpdate.listen((v) {
      setState(() {
        _bufferPos = v;
      });
      widget.changeBuffering(_buffering,_bufferPos,false);
    });

    _bufferingSubs = player.onBufferStateUpdate.listen((v) {
      setState(() {
        _buffering = v;
      });
      widget.changeBuffering(_buffering,_bufferPos,true);
    });
  }

  void _playerValueChanged() async {
    print("_playerValueChanged ${_playerValueChanged}");
    // await player.stop();
    FijkValue value = player.value;
    if (value.duration != _duration) {
      setState(() {
        _duration = value.duration;
      });
    }

    //print("value.duration ${value.duration}");

    //print('+++++++++ $value.state  播放器状态  ${value.state == FijkState.started} ++++++++++');
    bool playing = (value.state == FijkState.started);
    bool prepared = value.prepared;
    String? exception = value.exception.message;

    // 状态不一致，修改
    if (playing != _playing ||
        exception != _exception) {
      setState(() {
        _playing = playing;
        _exception = exception;
      });

      if(prepared!=_prepared){
        widget.changePrepared(_prepared);
        setState(() {
          _prepared = prepared;
        });
      }


    }

    // 播放完成
    bool playend = (value.state == FijkState.completed);

    var tmp = _videoSourceTabs.video![widget.curTabIdx]!.list;
    String nextVideoUrl = "";


    if (tmp!.length >widget.curActiveIdx + 1){
      nextVideoUrl = tmp[widget.curActiveIdx + 1]!.url!;
    }

    // 播放完成 && tablen没有溢出 && curActive没有溢出
    // ignore: unnecessary_null_comparison
    if (playend && nextVideoUrl != null && nextVideoUrl != "" && showConfig.autoNext) {
      int newTabIdx = widget.curTabIdx;
      int newActiveIdx = widget.curActiveIdx + 1;
      widget.onChangeVideo(newTabIdx, newActiveIdx);
      // 切换播放源
      changeCurPlayVideo(newTabIdx, newActiveIdx);
    }
  }

// +++++++++++++++++++++++++++++++++++++++++++

  _onHorizontalDragStart(detills) {
    setState(() {
      updatePrevDx = detills.globalPosition.dx;
      updatePosX = _currentPos.inSeconds;
    });
  }

  _onHorizontalDragUpdate(detills) {
    double curDragDx = detills.globalPosition.dx;
    // 确定当前是前进或者后退
    int cdx = curDragDx.toInt();
    int pdx = updatePrevDx!.toInt();
    bool isBefore = cdx > pdx;
    // + -, 不满足, 左右滑动合法滑动值，> 4
    if (isBefore && cdx - pdx < 2 || !isBefore && pdx - cdx < 2) return null;

    int dragRange = isBefore ? updatePosX! + 1 : updatePosX! - 1;

    // 是否溢出 最大
    int lastSecond = _duration.inSeconds;
    if (dragRange >= _duration.inSeconds) {
      dragRange = lastSecond;
    }
    // 是否溢出 最小
    if (dragRange <= 0) {
      dragRange = 0;
    }
    //
    this.setState(() {
      _isHorizontalMove = true;
      hideStuff = false;
      _isTouch = true;
      // 更新下上一次存的滑动位置
      updatePrevDx = curDragDx;
      // 更新时间
      updatePosX = dragRange.toInt();
      _dargPos = Duration(seconds: updatePosX!.toInt());
    });
  }

  _onHorizontalDragEnd(detills) async {
    print("player.start");
    await player.start();
    print("player.seekTo ${_dargPos.inMilliseconds}");
    await player.seekTo(_dargPos.inMilliseconds);
    this.setState(() {
      _isHorizontalMove = false;
      _isTouch = false;
      hideStuff = true;
      _currentPos = _dargPos;
    });
  }

// +++++++++++++++++++++++++++++++++++++++++++

  _onVerticalDragStart(detills) async {
    double clientW = widget.viewSize.width;
    double curTouchPosX = detills.globalPosition.dx;

    setState(() {
      // 更新位置
      updatePrevDy = detills.globalPosition.dy;
      // 是否左边
      isDargVerLeft = (curTouchPosX > (clientW / 2)) ? false : true;
    });
    // 大于 右边 音量 ， 小于 左边 亮度
    if (!isDargVerLeft!) {
      // 音量
      await FijkVolume.getVol().then((double v) {
        varTouchInitSuc = true;
        setState(() {
          updateDargVarVal = v;
        });
      });
    } else {
      // 亮度
      await FijkPlugin.screenBrightness().then((double v) {
        varTouchInitSuc = true;
        setState(() {
          updateDargVarVal = v;
        });
      });
    }
  }

  _onVerticalDragUpdate(detills) {
    if (!varTouchInitSuc) return null;
    double curDragDy = detills.globalPosition.dy;
    // 确定当前是前进或者后退
    int cdy = curDragDy.toInt();
    int pdy = updatePrevDy!.toInt();
    bool isBefore = cdy < pdy;
    // + -, 不满足, 上下滑动合法滑动值，> 3
    if (isBefore && pdy - cdy < 3 || !isBefore && cdy - pdy < 3) return null;
    // 区间
    double dragRange =
    isBefore ? updateDargVarVal! + 0.03 : updateDargVarVal! - 0.03;
    // 是否溢出
    if (dragRange > 1) {
      dragRange = 1.0;
    }
    if (dragRange < 0) {
      dragRange = 0.0;
    }
    setState(() {
      updatePrevDy = curDragDy;
      varTouchInitSuc = true;
      updateDargVarVal = dragRange;
      // 音量
      if (!isDargVerLeft!) {
        FijkVolume.setVol(dragRange);
      } else {
        FijkPlugin.setScreenBrightness(dragRange);
      }
    });
  }

  _onVerticalDragEnd(detills) {
    setState(() {
      varTouchInitSuc = false;
    });
  }

// +++++++++++++++++++++++++++++++++++++++++++

  // 切换播放源
  Future<void> changeCurPlayVideo(int tabIdx, int activeIdx) async {
    await player.stop();
    setState(() {
      _buffering = false;
    });
    widget.changeBuffering(_buffering,_bufferPos,true);
    player.reset().then((_) async {
      _speed = speed = 1.0;
      String curTabActiveUrl =
      _videoSourceTabs.video![tabIdx]!.list![activeIdx]!.url!;



      await player.setDataSource(
        curTabActiveUrl,
      );

      await player.setOption(FijkOption.playerCategory, "soundtouch", 1);
      /* await player.setOption(FijkOption.playerCategory, "analyzeduration",1);
        await player.setOption(FijkOption.formatCategory,"probesize",1024*10);
      await player.setOption(FijkOption.formatCategory,"framedrop",5);
      await player.setOption(FijkOption.formatCategory,"max-buffer-size",1024*10);
      await player.setOption(FijkOption.formatCategory, "analyzemaxduration", 100);
     await player.setOption(FijkOption.formatCategory, "flush_packets", 1);
      await player.setOption(FijkOption.playerCategory, "packet-buffering",0);*/
      /*await player.setOption(FijkOption.playerCategory, "find_stream_info",0);
      await player.setOption(FijkOption.playerCategory, "render-wait-start",1);*/
     /* await player.setOption(FijkOption.formatCategory, "cache_file_path","/storage/emulated/0/1.tmp");
      await player.setOption(FijkOption.formatCategory, "cache_map_path","/storage/emulated/0/2.tmp");
      await player.setOption(FijkOption.formatCategory, "parse_cache_map",1);
      await player.setOption(FijkOption.formatCategory, "auto_save_map",1);*/


      await player.setOption(FijkOption.formatCategory, "fflags", "fastseek");
      await player.setOption(FijkOption.playerCategory, "enable-accurate-seek", 1);
      //await player.setOption(FijkOption.playerCategory, "accurate-seek-timeout", 1);

      await player.prepareAsync();

      widget.onChangeVideo(tabIdx, activeIdx);
      await player.start();
     /* await player.setOption(FijkOption.playerCategory, "max-buffer-size", 100 *1024 * 1024);
      await player.setOption(FijkOption.playerCategory, "min-frames", 100);
      await player.setOption(FijkOption.playerCategory, "reconnect", 5);


      await player.setOption(FijkOption.formatCategory, "dns_cache_clear", 1);
      await player.setOption(FijkOption.playerCategory, "mediacodec", 0);
      await  player.setOption(FijkOption.playerCategory, "opensles", 0);

      await  player.setOption(FijkOption.playerCategory, "framedrop", 60);
      await  player.setOption(FijkOption.playerCategory, "start-on-prepared", 0);
      await  player.setOption(FijkOption.formatCategory, "http-detect-range-support", 0);
      await player.setOption(FijkOption.codecCategory, "skip_loop_filter", 0);
      await player.setOption(FijkOption.playerCategory, "soundtouch", 1);*/
     /* await player.setOption(FijkOption.playerCategory, "mediacodec", 1);
      await player.setOption(FijkOption.playerCategory, "framedrop", 5);
      await player.setOption(FijkOption.playerCategory, "skip_loop_filter", 48);
      await player.setOption(FijkOption.playerCategory, "probesize", 2048);//播放前的探测Size
      await player.setOption(FijkOption.playerCategory, "analyzeduration", 1);//

      await player.setOption(FijkOption.playerCategory, "http-detect-range-support", 0);
      await player.setOption(FijkOption.playerCategory, "analyzemaxduration", 100);
      await player.setOption(FijkOption.playerCategory, "flush_packets", 1);*/

      // 回调

    });
  }

  void _playOrPause() {
    _playing ? player.pause() : player.start();
  }

  void _cancelAndRestartTimer() {
    if (hideStuff == true) {
      _startHideTimer();
    }

    setState(() {
      hideStuff = !hideStuff;
      if (hideStuff == true) {
        _hideSpeedStu = true;
      }
    });
  }

  void _startHideTimer() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 5), () {
      setState(() {
        hideStuff = true;
        _hideSpeedStu = true;
      });
    });
  }

  // 底部控制栏 - 播放按钮
  Widget _buildPlayStateBtn() {
    IconData iconData = _playing ? Icons.pause : Icons.play_arrow;

    return IconButton(
      icon: Icon(iconData),
      color: Colors.white,
      padding: EdgeInsets.only(
        left: 10.0,
        right: 10.0,
      ),
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onPressed: _playOrPause,
    );
  }

  // 控制器ui 底部
  Widget _buildBottomBar(BuildContext context) {
    // 计算进度时间
    double duration = _duration.inMilliseconds.toDouble();
    double currentValue = _seekPos > 0
        ? _seekPos
        : (_isHorizontalMove
        ? _dargPos.inMilliseconds.toDouble()
        : _currentPos.inMilliseconds.toDouble());
    currentValue = min(currentValue, duration);
    currentValue = max(currentValue, 0);

    // 计算底部吸底进度
    double curConWidth = MediaQuery.of(context).size.width;
    double curTimePro = (currentValue / duration) * 100;
    double curBottomProW = (curConWidth / 100) * curTimePro;

    return Container(
      height: barHeight,
      child: Stack(
        children: [
          // 底部UI控制器

          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: AnimatedOpacity(
              opacity: hideStuff ? 0.0 : 0.8,
              duration: Duration(milliseconds: 400),
              child: Container(
                height: barHeight,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomLeft,
                    colors: [
                      Color.fromRGBO(0, 0, 0, 0),
                      Color.fromRGBO(0, 0, 0, 1),
                    ],
                  ),
                ),
                child: Row(
                  children: <Widget>[
                    // 按钮 - 播放/暂停
                    _buildPlayStateBtn(),
                    // 下一集
                    showConfig.nextBtn
                        ? IconButton(
                      icon: Icon(Icons.skip_next),
                      color: Colors.white,
                      padding: EdgeInsets.only(
                        left: 10.0,
                        right: 10.0,
                      ),
                      splashColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onPressed: () {
                        bool isOverFlowActiveLen =
                            widget.curActiveIdx + 1 >
                                _videoSourceTabs.video![widget.curTabIdx]!
                                    .list!.length;
                        // 播放完成
                        if (!isOverFlowActiveLen) {
                          int newTabIdx = widget.curTabIdx;
                          int newActiveIdx = widget.curActiveIdx + 1;
                          // 切换播放源
                          changeCurPlayVideo(newTabIdx, newActiveIdx);
                        }
                      },
                    )
                        : Container(),
                    // 已播放时间
                    Padding(
                      padding: EdgeInsets.only(right: 5.0, left: 5),
                      child: Text(
                        '${_duration2String(_currentPos)}',
                        style: TextStyle(
                          fontSize: 14.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    // 播放进度 if 没有开始播放 占满，空ui， else fijkSlider widget
                    _duration.inMilliseconds == 0
                        ? Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(right: 5, left: 5),
                        child: NewFijkSlider(
                          colors: NewFijkSliderColors(
                            cursorColor: Colors.lightBlueAccent,
                            playedColor: Colors.lightBlueAccent,
                          ),
                          onChangeEnd: (double value) {},
                          value: 0,
                          onChanged: (double value) {},
                        ),
                      ),
                    )
                        : Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(right: 5, left: 5),
                        child: NewFijkSlider(
                          colors: NewFijkSliderColors(
                            cursorColor: Colors.lightBlueAccent,
                            playedColor: Colors.lightBlueAccent,
                          ),
                          value: currentValue,
                          cacheValue:
                          _bufferPos.inMilliseconds.toDouble(),
                          min: 0.0,
                          max: duration,
                          onChanged: (v) {
                            _startHideTimer();
                            setState(() {
                              //print("seek to $v");
                              _seekPos = v;
                            });
                          },
                          onChangeEnd: (v) async {
                            print("player.start");
                            await player.start();
                            print("player.seekTo2 ${v.toInt()}");
                            await player.seekTo(v.toInt());
                            setState(() {
                              //print("seek to $v");
                              _currentPos = Duration(
                                  milliseconds: _seekPos.toInt());
                              _seekPos = -1;
                            });
                          },
                        ),
                      ),
                    ),

                    // 总播放时间
                    _duration.inMilliseconds == 0
                        ? Container(
                      child: const Text(
                        "00:00",
                        style: TextStyle(color: Colors.white),
                      ),
                    )
                        : Padding(
                      padding: EdgeInsets.only(right: 5.0, left: 5),
                      child: Text(
                        '${_duration2String(_duration)}',
                        style: TextStyle(
                          fontSize: 14.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    // 剧集按钮
                    widget.player.value.fullScreen && showConfig.drawerBtn
                        ? Ink(
                      padding: EdgeInsets.all(5),
                      child: InkWell(
                        onTap: () {
                          // 调用父组件的回调
                          widget.changeDrawerState(true);
                        },
                        child: Container(
                          alignment: Alignment.center,
                          width: 40,
                          height: 30,
                          child: Text(
                            "剧集",
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    )
                        : Container(),
                    // 倍数按钮
                    widget.player.value.fullScreen && showConfig.speedBtn
                        ? Ink(
                      padding: EdgeInsets.all(5),
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            _hideSpeedStu = !_hideSpeedStu;
                          });
                        },
                        child: Container(
                          alignment: Alignment.center,
                          width: 40,
                          height: 30,
                          child: Text(
                            _speed.toString() + " X",
                            style: TextStyle(color: Colors.white),
                          ),
                        ),
                      ),
                    )
                        : Container(),
                    // 按钮 - 全屏/退出全屏
                    IconButton(
                      icon: Icon(widget.player.value.fullScreen
                          ? Icons.fullscreen_exit
                          : Icons.fullscreen),
                      padding: EdgeInsets.only(left: 10.0, right: 10.0),
                      color: Colors.white,
                      splashColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      onPressed: () {
                        if (widget.player.value.fullScreen) {
                          player.exitFullScreen();
                        } else {
                          player.enterFullScreen();
                          // 掉父组件回调
                          widget.changeDrawerState(false);
                        }
                      },
                    )
                    //
                  ],
                ),
              ),
            ),
          ),
          // 隐藏进度条，ui隐藏时出现
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: showConfig.bottomPro &&
                hideStuff &&
                _duration.inMilliseconds != 0
                ? Container(
              alignment: Alignment.bottomLeft,
              height: 4,
              color: Colors.white70,
              child: Container(
                color: Colors.lightBlueAccent,
                width: curBottomProW is double ? curBottomProW : 0,
                height: 4,
              ),
            )
                : Container(),
          )
        ],
      ),
    );
  }

  // 返回按钮
  Widget _buildTopBackBtn() {
    return IconButton(
      icon: Icon(Icons.arrow_back),
      padding: EdgeInsets.only(
        left: 10.0,
        right: 10.0,
      ),
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      color: Colors.white,
      onPressed: () {
        // 判断当前是否全屏，如果全屏，退出
        if (widget.player.value.fullScreen) {
          player.exitFullScreen();
        } else {
          if (widget.currentCtx == null) return null;
          player.stop();
          Navigator.pop(widget.currentCtx!);
        }
      },
    );
  }

  // 播放器顶部 返回 + 标题
  Widget _buildTopBar() {
    return AnimatedOpacity(
      opacity: hideStuff ? 0.0 : 0.8,
      duration: Duration(milliseconds: 400),
      child: Container(
        height: showConfig.stateAuto && !widget.player.value.fullScreen
            ? barFillingHeight
            : barHeight,
        alignment: Alignment.bottomLeft,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomLeft,
            colors: [
              Color.fromRGBO(0, 0, 0, 1),
              Color.fromRGBO(0, 0, 0, 0),
            ],
          ),
        ),
        child: Container(
          height: barHeight,
          child: Row(
            children: <Widget>[
              _buildTopBackBtn(),
              Expanded(
                child: Container(
                  child: Text(
                    widget.playerTitle,
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // 居中播放按钮
  Widget _buildCenterPlayBtn() {
    return Container(
      color: Colors.transparent,
      height: double.infinity,
      width: double.infinity,
      child: Center(
        child: (_prepared && !_buffering)
            ? AnimatedOpacity(
          opacity: hideStuff ? 0.0 : 0.7,
          duration: Duration(milliseconds: 400),
          child: IconButton(
            iconSize: barHeight * 1.2,
            icon: Icon(_playing ? Icons.pause : Icons.play_arrow,
                color: Colors.white),
            padding: EdgeInsets.only(left: 10.0, right: 10.0),
            onPressed: _playOrPause,
          ),
        )
            : SizedBox(
          width: barHeight * 0.8,
          height: barHeight * 0.8,
          child: const CircularProgressIndicator(
            //loading
            valueColor: AlwaysStoppedAnimation(Colors.red),
          ),
        ),
      ),
    );
  }

  // build 滑动进度时间显示
  Widget _buildDargProgressTime() {
    return _isTouch
        ? Container(
      height: 40,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.all(
          Radius.circular(5),
        ),
        color: Color.fromRGBO(0, 0, 0, 0.8),
      ),
      child: Padding(
        padding: EdgeInsets.only(left: 10, right: 10),
        child: Text(
          '${_duration2String(_dargPos)} / ${_duration2String(_duration)}',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
          ),
        ),
      ),
    )
        : Container();
  }

  // build 显示垂直亮度，音量
  Widget _buildDargVolumeAndBrightness() {
    // 不显示
    if (!varTouchInitSuc) return Container();

    IconData iconData;
    // 判断当前值范围，显示的图标
    if (updateDargVarVal! <= 0) {
      iconData = !isDargVerLeft! ? Icons.volume_mute : Icons.brightness_low;
    } else if (updateDargVarVal! < 0.5) {
      iconData = !isDargVerLeft! ? Icons.volume_down : Icons.brightness_medium;
    } else {
      iconData = !isDargVerLeft! ? Icons.volume_up : Icons.brightness_high;
    }
    // 显示，亮度 || 音量
    return Card(
      color: Color.fromRGBO(0, 0, 0, 0.8),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Icon(
              iconData,
              color: Colors.white,
            ),
            Container(
              width: 100,
              height: 3,
              margin: EdgeInsets.only(left: 8),
              child: LinearProgressIndicator(
                value: updateDargVarVal,
                backgroundColor: Colors.white54,
                valueColor: AlwaysStoppedAnimation(Colors.lightBlue),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // build 倍数列表
  List<Widget> _buildSpeedListWidget() {
    List<Widget> columnChild = [];
    speedList.forEach((String mapKey, double speedVals) {
      columnChild.add(
        Ink(
          child: InkWell(
            onTap: () {
              if (_speed == speedVals) return null;
              setState(() {
                _speed = speed = speedVals;
                _hideSpeedStu = true;
                player.setSpeed(speedVals);
              });
            },
            child: Container(
              alignment: Alignment.center,
              width: 50,
              height: 24,
              child: Text(
                mapKey + " X",
                style: TextStyle(
                  color: _speed == speedVals ? Colors.lightBlueAccent : Colors.white,
                  fontSize: 16,
                ),
              ),
            ),
          ),
        ),
      );
      columnChild.add(
        Padding(
          padding: EdgeInsets.only(top: 5, bottom: 5),
          child: Container(
            width: 50,
            height: 1,
            color: Colors.white54,
          ),
        ),
      );
    });
    columnChild.removeAt(columnChild.length - 1);
    return columnChild;
  }

  // 播放器控制器 ui
  Widget buildGestureDetector() {
    print(111);
    return IndexedStack(
      children: [
      GestureDetector(
      //  onDoubleTap: _playOrPause,
        onTap: _cancelAndRestartTimer,
        //点击
        behavior: HitTestBehavior.opaque,
        //在命中测试时，将当前组件当成不透明处理(即使本身是透明的)，最终的效果相当于当前Widget的整个区域都是点击区域。
        onHorizontalDragStart: _onHorizontalDragStart,
        //水平移动开始
        onHorizontalDragUpdate: _onHorizontalDragUpdate,
        //水平移动过程中
        onHorizontalDragEnd: _onHorizontalDragEnd,
        //水平移动结束
        onVerticalDragStart: _onVerticalDragStart,
        //垂直移动开始
        onVerticalDragUpdate: _onVerticalDragUpdate,
        //垂直移动开始
        onVerticalDragEnd: _onVerticalDragEnd,
        //垂直移动开始
        child: AbsorbPointer(
          //拦截点击
          absorbing: hideStuff, //拦截
          child: Column(
            children: <Widget>[
              // 播放器顶部控制器
              showConfig.topBar
                  ? _buildTopBar()
                  : Container(
                height: showConfig.stateAuto &&
                    !widget.player.value
                        .fullScreen // fullScreen 是否应以全屏模式显示播放机
                    ? barFillingHeight
                    : barHeight,
              ),
              // 中间按钮
              Expanded(
                child: Stack(
                  children: <Widget>[
                    // 顶部显示
                    Positioned(
                      top: widget.player.value.fullScreen ? 20 : 0,
                      left: 0,
                      right: 0,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // 显示左右滑动快进时间的块
                          _buildDargProgressTime(),
                          // 显示上下滑动音量亮度
                          _buildDargVolumeAndBrightness()
                        ],
                      ),
                    ),
                    // 中间按钮
                    Align(
                      alignment: Alignment.center,
                      child: _buildCenterPlayBtn(),
                    ),
                    // 倍数选择
                    Positioned(
                      right: 35,
                      bottom: 0,
                      child: !_hideSpeedStu
                          ? Container(
                        child: Padding(
                          padding: EdgeInsets.all(10),
                          child: Column(
                            children: _buildSpeedListWidget(),
                          ),
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black45,
                          borderRadius: BorderRadius.circular(10),
                        ),
                      )
                          : Container(),
                    ),
                    // 锁按钮
                    showConfig.lockBtn && widget.player.value.fullScreen
                        ? Align(
                      alignment: Alignment.centerLeft,
                      child: AnimatedOpacity(
                        opacity: hideStuff ? 0.0 : 0.7,
                        duration: Duration(milliseconds: 400),
                        child: Padding(
                          padding: EdgeInsets.only(left: 20),
                          child: IconButton(
                            iconSize: 30,
                            onPressed: () {
                              // 更改 ui显示状态
                              widget.changeLockState(true);
                            },
                            icon: Icon(Icons.lock_outline),
                            color: Colors.white,
                          ),
                        ),
                      ),
                    )
                        : Container(),
                  ],
                ),
              ),

              // 播放器底部控制器
              _buildBottomBar(context),
            ],
          ),
        ),
      )
    ],);
  }

  @override
  Widget build(BuildContext context) {
    return buildGestureDetector();
  }
}

//格式化时间
String _duration2String(Duration duration) {
  if (duration.inMilliseconds < 0) return "-: negtive";

  String twoDigits(int n) {
    if (n >= 10) return "$n";
    return "0$n";
  }

  String twoDigitMinutes = twoDigits(duration.inMinutes.remainder(60));
  String twoDigitSeconds = twoDigits(duration.inSeconds.remainder(60));
  int inHours = duration.inHours;
  return inHours > 0
      ? "$inHours:$twoDigitMinutes:$twoDigitSeconds"
      : "$twoDigitMinutes:$twoDigitSeconds";
}