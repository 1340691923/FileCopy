import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:ifwang/utils/test.dart';
import 'package:webview_flutter/webview_flutter.dart';
class CustomTabBarView extends StatefulWidget {

  String kw = "";

  Map<String,dynamic> wordParse = {};

  CustomTabBarView(this.kw,this.wordParse);

  @override
  _CustomTabBarViewState createState() => _CustomTabBarViewState();
}


class _CustomTabBarViewState extends State<CustomTabBarView> with SingleTickerProviderStateMixin {
  final tabs = ['单词翻译','释义','词组','双语例句', '相关图片'];
  TabController? _tabController;
  AudioPlayer audioPlayer = AudioPlayer();



  Map<String, List<Widget>>? wordPraseMap = {};
  Map<String, List<Widget>>? lijuMap = {};
  Map<String, List<Widget>>? word_groupMap = {};

  @override
  void initState() {
   // widget.wordParse[""]
    buildParse();
    super.initState();

    audioPlayer.onAudioPositionChanged.listen((p) async {
      print(p);
    });
    _tabController = TabController(vsync: this, length: tabs.length);
  }



  void buildParse(){
    List<Widget> chinese_fanyi = [];

    if(widget.wordParse.containsKey("chinese_fanyi") && widget.wordParse.containsKey("chinese_fanyi") != null){
      (widget.wordParse["chinese_fanyi"] as List<dynamic>).forEach((element) {
        chinese_fanyi.add( Text(element,style: TextStyle(color: Colors.white)));
      });
    }

    List<Widget> yinbiaoList = [];

    if(widget.wordParse.containsKey("ying_ying_biao")){
      yinbiaoList.add( Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,children: [
        Text("英： ${widget.wordParse["ying_ying_biao"]}" ,style: TextStyle(color: Colors.white)),
        IconButton(
          icon: Icon(Icons.play_circle_filled),
          color:  Colors.orange,
          iconSize:  25.0,

          splashColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onPressed: () async {
            var uri = "https://dict.youdao.com/dictvoice?audio="+widget.kw+"&type=1";
            print("${ uri}");
            await audioPlayer.play(uri);
          },
        )
      ],));
    }

    if(widget.wordParse.containsKey("mei_ying_biao")){
      yinbiaoList.add(  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,children: [
        Text("美： ${widget.wordParse["mei_ying_biao"]}" ,style: TextStyle(color: Colors.white)),
        IconButton(
          icon: Icon(Icons.play_circle_filled),
          color:  Colors.orange,
          iconSize:  25.0,

          splashColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onPressed: () async {
            print("${ widget.wordParse["mei_audio"]}");
            await audioPlayer.play("https://dict.youdao.com/dictvoice?audio="+widget.kw+"&type=2");
          },
        )
      ],));
    }

    setState(() {

      wordPraseMap!["单词：${widget.wordParse["danci"]}"] = chinese_fanyi;

      wordPraseMap!["音标"] = yinbiaoList;

      if(widget.wordParse.containsKey("additional")){
        var str = (widget.wordParse["additional"] as String).replaceAll(" ", "");
        wordPraseMap![str] = [];
      }

      if(widget.wordParse.containsKey("shuang_yu_li_ju")){
        (widget.wordParse["shuang_yu_li_ju"] as Map<String,dynamic>).forEach((key, value) {
          lijuMap![key] = [Text(value,style: TextStyle(color: Colors.white))];
        });
      }

      if(widget.wordParse.containsKey("word_group")){
        (widget.wordParse["word_group"] as Map<String,dynamic>).forEach((key, value) {
          word_groupMap![key] = [Text(value,style: TextStyle(color: Colors.white))];
        });
      }

    });
  }

  @override
  void dispose() {
    _tabController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return  Container(
        child: Column(
          children: <Widget>[
            _buildTabBar(),
            Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height-50,
                child: _buildTableBarView())
          ],
        ),
      );
  }

  Widget _buildTabBar() => TabBar(
    onTap: (tab) => print(tab),
    labelStyle: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
    unselectedLabelStyle: TextStyle(fontSize: 16),
    isScrollable: true,
    controller: _tabController,
    labelColor: Colors.blue,
    indicatorWeight: 3,
    indicatorPadding: EdgeInsets.symmetric(horizontal: 10),
    unselectedLabelColor: Colors.grey,
    indicatorColor: Colors.orangeAccent,
    tabs: tabs.map((e) => Tab(text: e)).toList(),
  );

  Widget _buildTableBarView() => TabBarView(
      controller: _tabController,
      children: [
        DanCiShiYi(wordPraseMap!),
        DanCiShiYi(wordPraseMap!),
        DanCiShiYi(word_groupMap!),
        DanCiShiYi(lijuMap!),
        Center(child: WebView(

          //initialUrl: "https://docs.qq.com/doc/p/0c53403adc142c77f9d8223a5611efbdbe007639?dver=2.1.27232530",
          initialUrl: "https://cn.bing.com/images/search?q="+widget.kw+"&first=1&tsc=ImageHoverTitle&ensearch=1&form=BESBTB",
          //JS执行模式 是否允许JS执行
          javascriptMode: JavascriptMode.unrestricted,
          gestureNavigationEnabled: true,
        )),
      ]);
}
